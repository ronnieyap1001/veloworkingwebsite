import { useEffect } from "react";
import { useLang } from "@/contexts/LanguageContext";
import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { motion } from "framer-motion";
import {
  ArrowRight, Hammer, Cpu, CircuitBoard, Cable,
  ClipboardCheck, Truck, Cog, TestTube, MessageCircle,
} from "lucide-react";
import { Link } from "wouter";

const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%20need%20fabrication%20services...";

const IMAGES = {
  controlPanel: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/control-panel-plc_5c5099c6.webp",
  metalFab: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/metal-fabrication-workshop_fe9e7e56.jpg",
  wireHarness: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/wire-harness-assembly_a353491f.jpg",
  pcba: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/pcba-assembly_25514a10.jpg",
};

export default function Engineering() {
  const { t, lang } = useLang();

  useEffect(() => {
    document.title = lang === "en"
      ? "Fabrication & Assembly | Control Panels, Wire Harnesses, PCBA — Velo Working"
      : "制造与装配 | 控制面板、线束、PCBA — Velo Working";
  }, [lang]);

  const services = [
    {
      icon: Hammer,
      img: IMAGES.metalFab,
      titleKey: "eng.metal.title",
      descKey: "eng.metal.desc",
    },
    {
      icon: Cpu,
      img: IMAGES.controlPanel,
      titleKey: "eng.box.title",
      descKey: "eng.box.desc",
    },
    {
      icon: CircuitBoard,
      img: IMAGES.pcba,
      titleKey: "eng.pcba.title",
      descKey: "eng.pcba.desc",
    },
    {
      icon: Cable,
      img: IMAGES.wireHarness,
      titleKey: "eng.wire.title",
      descKey: "eng.wire.desc",
    },
  ];

  const steps = [
    { icon: Truck, titleKey: "eng.step1.title", descKey: "eng.step1.desc" },
    { icon: ClipboardCheck, titleKey: "eng.step2.title", descKey: "eng.step2.desc" },
    { icon: Cog, titleKey: "eng.step3.title", descKey: "eng.step3.desc" },
    { icon: TestTube, titleKey: "eng.step4.title", descKey: "eng.step4.desc" },
  ];

  return (
    <Layout>
      {/* ─── Hero ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("eng.page.label")}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="mt-4 text-[clamp(2.5rem,5vw,4rem)] leading-[1.1] text-white whitespace-pre-line max-w-3xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("eng.page.heading")}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-[clamp(0.9375rem,2vw,1.125rem)] text-white/50 leading-relaxed max-w-xl"
          >
            {t("eng.page.intro")}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-8 flex flex-wrap gap-4"
          >
            <Link href="/contact" className="btn-brand btn-brand-filled inline-flex items-center gap-2">
              {t("eng.cta")}
              <ArrowRight size={16} />
            </Link>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
              className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2">
              <MessageCircle size={16} />
              {t("hero.whatsapp")}
            </a>
          </motion.div>
        </div>
      </section>

      {/* ─── What We Build ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("eng.what.label")}</p>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
            {services.map((svc, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="group bg-white border border-[#E5E7EB] overflow-hidden hover:border-[#1317E4]/40 transition-colors duration-300">
                  <div className="h-56 overflow-hidden">
                    <img
                      src={svc.img}
                      alt={t(svc.titleKey)}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <svc.icon size={20} className="text-[#1317E4]" />
                      <h3 className="text-lg font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>
                        {t(svc.titleKey)}
                      </h3>
                    </div>
                    <p className="text-sm text-[#6B7280] leading-relaxed">{t(svc.descKey)}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Our Process ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("eng.how.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight whitespace-pre-line" style={{ fontFamily: "var(--font-heading)" }}>
              {t("eng.how.heading")}
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-14">
            {steps.map((step, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className="relative">
                  <span className="text-6xl font-bold text-[#1317E4]/10 leading-none block" style={{ fontFamily: "var(--font-heading)" }}>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="mt-1">
                    <step.icon size={22} className="text-[#1317E4] mb-3" />
                    <h3 className="text-base font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>{t(step.titleKey)}</h3>
                    <p className="mt-2 text-sm text-[#6B7280] leading-relaxed">{t(step.descKey)}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Cross-sell to ERP Rescue ─── */}
      <section className="bg-[#1317E4] py-16">
        <div className="container text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] uppercase text-white/50 mb-4">
              {lang === "en" ? "We Also Fix Systems" : "我们也修复系统"}
            </p>
            <h2 className="text-[clamp(1.6rem,3.5vw,2.5rem)] text-white leading-tight max-w-2xl mx-auto" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en"
                ? "Need your ERP fixed too? We're the only team that builds hardware and configures software."
                : "ERP也需要修复？我们是唯一既做硬件又配置软件的团队。"}
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="mt-8">
              <Link href="/erp-rescue" className="btn-brand btn-brand-white inline-flex items-center gap-2">
                {lang === "en" ? "Explore ERP Rescue" : "了解ERP拯救"}
                <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="bg-[#111111] py-16">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("eng.cta")}
            </h2>
            <p className="mt-4 text-white/50 text-lg max-w-lg mx-auto">
              {lang === "en"
                ? "From raw material to commissioned system — tell us what you need built."
                : "从原材料到调试完成的系统 — 告诉我们您需要制造什么。"}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link href="/contact" className="btn-brand btn-brand-filled inline-flex items-center gap-2">
                {t("eng.cta")}
                <ArrowRight size={16} />
              </Link>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2">
                <MessageCircle size={16} />
                {t("hero.whatsapp")}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
