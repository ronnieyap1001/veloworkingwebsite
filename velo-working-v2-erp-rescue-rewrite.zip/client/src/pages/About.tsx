import { useEffect } from "react";
import { useLang } from "@/contexts/LanguageContext";
import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { motion } from "framer-motion";
import { ArrowRight, Heart, Eye, Shield, MessageCircle } from "lucide-react";
import { Link } from "wouter";

const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%27d%20like%20to%20learn%20more...";

export default function About() {
  const { t, lang } = useLang();

  useEffect(() => {
    document.title = lang === "en"
      ? "About Velo Working | ERP Rescue for Manufacturing SMEs"
      : "关于 Velo Working | 制造业中小企业ERP拯救";
  }, [lang]);

  const values = [
    { icon: Heart, titleKey: "about.value1.title", descKey: "about.value1.desc" },
    { icon: Eye, titleKey: "about.value2.title", descKey: "about.value2.desc" },
    { icon: Shield, titleKey: "about.value3.title", descKey: "about.value3.desc" },
  ];

  const industries = lang === "en"
    ? [
        "Precision Machining & Manufacturing",
        "Semiconductor & Electronics Assembly",
        "Oil & Gas Services",
        "Logistics & Warehousing",
        "F&B Manufacturing",
        "Trading & Distribution",
      ]
    : [
        "精密加工与制造",
        "半导体与电子组装",
        "油气服务",
        "物流与仓储",
        "食品制造",
        "贸易与分销",
      ];

  return (
    <Layout>
      {/* ─── Hero ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("about.label")}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="mt-4 text-[clamp(2.5rem,5vw,4rem)] leading-[1.1] text-white whitespace-pre-line max-w-3xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("about.heading")}
          </motion.h1>
        </div>
      </section>

      {/* ─── About / Founder Story ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container max-w-3xl">
          <Reveal>
            <p className="text-lg text-[#111111] leading-relaxed">
              {t("about.intro")}
            </p>
          </Reveal>

          <Reveal delay={0.1}>
            <p className="mt-8 text-base text-[#6B7280] leading-relaxed">
              {t("about.founder")}
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <p className="mt-6 text-base text-[#6B7280] leading-relaxed">
              {t("about.mission")}
            </p>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="mt-10 border-l-4 border-[#1317E4] pl-6">
              <p className="text-lg text-[#111111] italic leading-relaxed" style={{ fontFamily: "var(--font-heading)" }}>
                {lang === "en"
                  ? "\"The question is no longer 'should I get an ERP?' The question is 'how much longer can I compete without one?'\""
                  : "\"问题不再是'我要不要上ERP？'而是'没有ERP我还能竞争多久？'\""}
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.25}>
            <div className="mt-12 bg-[#F8F9FA] p-6">
              <p className="text-sm text-[#6B7280] uppercase tracking-widest mb-2">{lang === "en" ? "The Founder" : "创始人"}</p>
              <p className="text-base font-bold text-[#111111]">Ronnie Yap</p>
              <p className="mt-1 text-sm text-[#6B7280] leading-relaxed">
                {lang === "en"
                  ? "PMP certified. Background in fabrication, industrial automation, control panels, wire harnesses, PCBA, and ERP/MES implementation. Founded Velo Working to close the digitalization gap for manufacturing SMEs."
                  : "PMP认证。背景涵盖制造、工业自动化、控制面板、线束、PCBA和ERP/MES实施。创立Velo Working，致力于缩小制造业中小企业的数字化差距。"}
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ─── Our Beliefs ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("about.values.label")}</p>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
            {values.map((v, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className="bg-white border border-[#E5E7EB] p-8 h-full hover:border-[#1317E4]/40 transition-colors duration-300">
                  <v.icon size={28} className="text-[#1317E4] mb-5" />
                  <h3 className="text-lg font-bold text-[#111111] mb-3" style={{ fontFamily: "var(--font-heading)" }}>
                    {t(v.titleKey)}
                  </h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{t(v.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Industries ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container max-w-3xl">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Industries We Serve" : "我们服务的行业"}</p>
          </Reveal>
          <Reveal delay={0.08}>
            <div className="mt-10 grid grid-cols-2 md:grid-cols-3 gap-3">
              {industries.map((ind, i) => (
                <div key={i} className="border border-[#E5E7EB] px-4 py-3 text-sm text-[#6B7280]">{ind}</div>
              ))}
            </div>
            <p className="mt-4 text-xs text-[#6B7280]/60">
              {lang === "en"
                ? "If your industry isn't listed, it doesn't mean we can't help — it means we'll spend more time learning your business first."
                : "如果您的行业不在列表中，不代表我们无法帮助 — 只是我们会花更多时间先了解您的业务。"}
            </p>
          </Reveal>
        </div>
      </section>

      {/* ─── Company Info ─── */}
      <section className="bg-[#111111] py-16">
        <div className="container max-w-3xl">
          <Reveal>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div>
                <p className="text-sm font-bold text-white tracking-widest">{t("about.company")}</p>
                <p className="text-xs text-white/40 mt-1">{t("about.uen")}</p>
                <p className="text-xs text-white/40 mt-1">{t("contact.address")}</p>
              </div>
              <div className="flex gap-4">
                <Link href="/contact" className="btn-brand btn-brand-filled inline-flex items-center gap-2 text-sm">
                  {t("hero.cta")}
                  <ArrowRight size={14} />
                </Link>
                <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                  className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2 text-sm">
                  <MessageCircle size={14} />
                  {t("hero.whatsapp")}
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
