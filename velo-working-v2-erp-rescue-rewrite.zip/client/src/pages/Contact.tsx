import { useEffect, useState } from "react";
import { useLang } from "@/contexts/LanguageContext";
import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { motion } from "framer-motion";
import {
  MapPin, Phone, Mail, MessageCircle, ArrowRight, CheckCircle,
} from "lucide-react";

const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%27d%20like%20to%20book%20a%20free%20ERP%20audit...";

export default function Contact() {
  const { t, lang } = useLang();
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    document.title = lang === "en"
      ? "Contact Us | Book a Free ERP Audit — Velo Working"
      : "联系我们 | 预约免费ERP诊断 — Velo Working";
  }, [lang]);

  const situations = [
    { value: "graveyard", labelKey: "contact.form.situation.graveyard" },
    { value: "excel", labelKey: "contact.form.situation.excel" },
    { value: "growing", labelKey: "contact.form.situation.growing" },
    { value: "lockedin", labelKey: "contact.form.situation.lockedin" },
    { value: "ai", labelKey: "contact.form.situation.ai" },
    { value: "fab", labelKey: "contact.form.situation.fab" },
    { value: "other", labelKey: "contact.form.situation.other" },
  ];

  const headcountOptions = lang === "en"
    ? ["1–10", "11–30", "31–50", "51–100", "100+"]
    : ["1–10人", "11–30人", "31–50人", "51–100人", "100人以上"];

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // In production, this would submit to an API endpoint
    setSubmitted(true);
  };

  const inputClasses =
    "w-full border border-[#E5E7EB] bg-white text-[#111111] text-sm px-4 py-3 focus:outline-none focus:border-[#1317E4] transition-colors placeholder:text-[#6B7280]/50";

  return (
    <Layout>
      {/* ─── Hero ─── */}
      <section className="bg-[#111111] py-24 lg:py-28">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("contact.label")}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="mt-4 text-[clamp(2.5rem,5vw,4rem)] leading-[1.1] text-white whitespace-pre-line max-w-3xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("contact.heading")}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-lg text-white/50 max-w-xl leading-relaxed"
          >
            {t("contact.sub")}
          </motion.p>
        </div>
      </section>

      {/* ─── Form + Contact Info ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
            {/* Left — Contact Info */}
            <div className="lg:col-span-2">
              <Reveal>
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <MapPin size={20} className="text-[#1317E4] mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-1">{lang === "en" ? "Office" : "办公室"}</p>
                      <p className="text-sm text-[#111111] leading-relaxed">{t("contact.address")}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Phone size={20} className="text-[#1317E4] mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-1">{lang === "en" ? "Phone" : "电话"}</p>
                      <a href="tel:+6598943004" className="text-sm text-[#111111] hover:text-[#1317E4] transition-colors">
                        {t("contact.phone")}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Mail size={20} className="text-[#1317E4] mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-1">{lang === "en" ? "Email" : "邮箱"}</p>
                      <a href="mailto:sales@veloworking.com" className="text-sm text-[#111111] hover:text-[#1317E4] transition-colors">
                        {t("contact.email")}
                      </a>
                    </div>
                  </div>

                  <div className="pt-4">
                    <a
                      href={WHATSAPP_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-brand btn-brand-outline inline-flex items-center gap-2"
                    >
                      <MessageCircle size={16} />
                      {t("contact.whatsapp")}
                    </a>
                  </div>
                </div>
              </Reveal>
            </div>

            {/* Right — Form */}
            <div className="lg:col-span-3">
              <Reveal delay={0.1}>
                {submitted ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <CheckCircle size={48} className="text-[#10B981] mb-4" />
                    <p className="text-lg font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>
                      {t("contact.form.success")}
                    </p>
                  </div>
                ) : (
                  <>
                    <h2 className="text-xl font-bold text-[#111111] mb-8" style={{ fontFamily: "var(--font-heading)" }}>
                      {t("contact.form.title")}
                    </h2>
                    <form onSubmit={handleSubmit} className="space-y-5">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <input
                          type="text"
                          name="name"
                          placeholder={t("contact.form.name")}
                          required
                          className={inputClasses}
                        />
                        <input
                          type="text"
                          name="company"
                          placeholder={t("contact.form.company")}
                          required
                          className={inputClasses}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <input
                          type="text"
                          name="industry"
                          placeholder={t("contact.form.industry")}
                          className={inputClasses}
                        />
                        <select name="headcount" className={inputClasses} required>
                          <option value="">{t("contact.form.headcount")}</option>
                          {headcountOptions.map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      </div>

                      <select name="situation" className={inputClasses} required>
                        <option value="">{t("contact.form.situation")}</option>
                        {situations.map((s) => (
                          <option key={s.value} value={s.value}>{t(s.labelKey)}</option>
                        ))}
                      </select>

                      <textarea
                        name="message"
                        rows={4}
                        placeholder={t("contact.form.message")}
                        className={inputClasses + " resize-none"}
                      />

                      <button
                        type="submit"
                        className="btn-brand btn-brand-filled w-full inline-flex items-center justify-center gap-2"
                      >
                        {t("contact.form.submit")}
                        <ArrowRight size={16} />
                      </button>
                    </form>
                  </>
                )}
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Map Placeholder ─── */}
      <section className="bg-[#F8F9FA]">
        <div className="h-72 bg-[#E5E7EB] flex items-center justify-center">
          <p className="text-sm text-[#6B7280]">
            540 Sims Ave, Sims Avenue Centre #03-05, Singapore 387603
          </p>
        </div>
      </section>
    </Layout>
  );
}
