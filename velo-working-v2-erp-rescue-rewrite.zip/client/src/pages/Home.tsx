import Layout from "@/components/Layout";
import { useEffect } from "react";
import { useLang } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import {
  MessageCircle, ArrowRight, AlertTriangle, FileSpreadsheet, Brain,
  Wrench, ShieldCheck, Clock, Users, TrendingUp, Lock, Cpu, Factory,
  Cable, CircuitBoard, Hammer,
} from "lucide-react";
import { Link } from "wouter";
import Reveal from "@/components/Reveal";

const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%20need%20help%20with%20my%20ERP%20system...";

const VIDEO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/veloworking_hero_background_193494ff.mp4";

const IMAGES = {
  controlPanel: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/control-panel-plc_5c5099c6.webp",
  metalFab: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/metal-fabrication-workshop_fe9e7e56.jpg",
  wireHarness: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/wire-harness-assembly_a353491f.jpg",
  pcba: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/pcba-assembly_25514a10.jpg",
};

export default function Home() {
  const { t, lang } = useLang();

  useEffect(() => {
    document.title = lang === "en"
      ? "Velo Working | ERP Rescue for Manufacturing SMEs — Singapore"
      : "Velo Working | 制造业中小企业ERP拯救 — 新加坡";
  }, [lang]);

  const profiles = [
    { icon: AlertTriangle, titleKey: "home.p1.title", descKey: "home.p1.desc", color: "#DC2626" },
    { icon: FileSpreadsheet, titleKey: "home.p2.title", descKey: "home.p2.desc", color: "#F59E0B" },
    { icon: TrendingUp, titleKey: "home.p3.title", descKey: "home.p3.desc", color: "#10B981" },
    { icon: Lock, titleKey: "home.p4.title", descKey: "home.p4.desc", color: "#8B5CF6" },
    { icon: Brain, titleKey: "home.p5.title", descKey: "home.p5.desc", color: "#1317E4" },
  ];

  const differentiators = [
    { icon: Wrench, titleKey: "home.diff1.title", descKey: "home.diff1.desc" },
    { icon: ShieldCheck, titleKey: "home.diff2.title", descKey: "home.diff2.desc" },
    { icon: Clock, titleKey: "home.diff3.title", descKey: "home.diff3.desc" },
  ];

  const fabServices = [
    { icon: Hammer, img: IMAGES.metalFab, title: lang === "en" ? "Metal Fabrication" : "金属加工" },
    { icon: Cpu, img: IMAGES.controlPanel, title: lang === "en" ? "Control Panels" : "控制面板" },
    { icon: CircuitBoard, img: IMAGES.pcba, title: lang === "en" ? "PCBA" : "PCBA组装" },
    { icon: Cable, img: IMAGES.wireHarness, title: lang === "en" ? "Wire Harnessing" : "线束加工" },
  ];

  return (
    <Layout>
      {/* ─── Video Hero ─── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover">
          <source src={VIDEO_URL} type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black/65" />

        <div className="container relative z-10 py-24 lg:py-0">
          <div className="max-w-3xl">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-[0.75rem] tracking-[0.3em] uppercase text-white/60 mb-6"
              style={{ fontFamily: "var(--font-body)" }}
            >
              {t("hero.label")}
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="text-[clamp(2.5rem,5vw,4rem)] leading-[1.1] tracking-tight text-white whitespace-pre-line"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              {t("hero.heading")}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-8 text-[clamp(0.9375rem,2vw,1.125rem)] text-white/70 max-w-xl leading-relaxed"
            >
              {t("hero.sub")}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              <Link href="/contact" className="btn-brand btn-brand-filled inline-flex items-center gap-2">
                {t("hero.cta")}
                <ArrowRight size={16} />
              </Link>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2"
              >
                <MessageCircle size={16} />
                {t("hero.whatsapp")}
              </a>
            </motion.div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
          <div className="w-[1px] h-12 bg-white/30 animate-pulse" />
        </div>
      </section>

      {/* ─── Why Every Company Needs a Digital System ─── */}
      <section className="bg-white py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("home.why.label")}</p>
            <h2 className="mt-4 text-[clamp(2rem,5vw,3.5rem)] leading-[1.05] text-[#111111] whitespace-pre-line max-w-2xl" style={{ fontFamily: "var(--font-heading)" }}>
              {t("home.why.heading")}
            </h2>
            <p className="mt-6 text-lg text-[#6B7280] leading-relaxed max-w-2xl">
              {t("home.why.desc")}
            </p>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-14">
            {[
              { titleKey: "home.why.col1.title", descKey: "home.why.col1.desc", icon: Users },
              { titleKey: "home.why.col2.title", descKey: "home.why.col2.desc", icon: FileSpreadsheet },
              { titleKey: "home.why.col3.title", descKey: "home.why.col3.desc", icon: Brain },
            ].map((item, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className="border border-[#E5E7EB] p-8 h-full hover:border-[#1317E4]/40 transition-colors duration-300">
                  <item.icon size={28} className="text-[#1317E4] mb-5" />
                  <h3 className="text-base font-bold text-[#111111] mb-3" style={{ fontFamily: "var(--font-heading)" }}>{t(item.titleKey)}</h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{t(item.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Which One Are You — 5 Client Profiles ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label !text-white">{t("home.profiles.label")}</p>
            <h2 className="mt-4 text-[clamp(2rem,5vw,3.5rem)] leading-[1.05] text-white whitespace-pre-line" style={{ fontFamily: "var(--font-heading)" }}>
              {t("home.profiles.heading")}
            </h2>
            <p className="mt-4 text-lg text-white/50 max-w-xl">{t("home.profiles.sub")}</p>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-14">
            {profiles.map((p, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="border border-white/10 p-7 h-full hover:border-white/25 transition-colors duration-300 flex flex-col">
                  <div className="w-10 h-10 flex items-center justify-center mb-5" style={{ borderColor: p.color, borderWidth: 2 }}>
                    <p.icon size={20} style={{ color: p.color }} />
                  </div>
                  <h3 className="text-[0.95rem] font-bold text-white mb-3 leading-snug" style={{ fontFamily: "var(--font-heading)" }}>
                    {t(p.titleKey)}
                  </h3>
                  <p className="text-sm text-white/45 leading-relaxed flex-1">{t(p.descKey)}</p>
                </div>
              </Reveal>
            ))}
            {/* CTA card */}
            <Reveal delay={0.4}>
              <Link href="/erp-rescue" className="border-2 border-[#1317E4] p-7 h-full flex flex-col justify-center items-center text-center hover:bg-[#1317E4]/10 transition-colors duration-300">
                <p className="text-lg font-bold text-[#1317E4] mb-2" style={{ fontFamily: "var(--font-heading)" }}>
                  {lang === "en" ? "See How We Fix It" : "了解我们如何修复"}
                </p>
                <ArrowRight size={20} className="text-[#1317E4]" />
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ─── What Sets Us Apart ─── */}
      <section className="bg-[#1317E4] py-16 lg:py-20">
        <div className="container">
          <Reveal>
            <p className="section-label !text-white/60">{t("home.diff.label")}</p>
            <h2 className="mt-3 text-[clamp(1.6rem,3.5vw,2.5rem)] text-white leading-tight max-w-xl" style={{ fontFamily: "var(--font-heading)" }}>
              {t("home.diff.heading")}
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0 mt-12">
            {differentiators.map((item, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className={`py-8 px-8 ${i < differentiators.length - 1 ? "border-b md:border-b-0 md:border-r border-white/20" : ""}`}>
                  <item.icon size={26} className="text-white/80 mb-5" />
                  <h3 className="text-base font-bold text-white mb-3" style={{ fontFamily: "var(--font-heading)" }}>{t(item.titleKey)}</h3>
                  <p className="text-sm text-white/60 leading-relaxed">{t(item.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Fabrication — Credibility Anchor ─── */}
      <section className="bg-[#F8F9FA] py-24 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("home.eng.label")}</p>
            <h2 className="mt-4 text-[clamp(2rem,5vw,3.5rem)] leading-[1.05] text-[#111111] whitespace-pre-line max-w-2xl" style={{ fontFamily: "var(--font-heading)" }}>
              {t("home.eng.heading")}
            </h2>
            <p className="mt-6 text-lg text-[#6B7280] leading-relaxed max-w-2xl">
              {t("home.eng.desc")}
            </p>
          </Reveal>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-14">
            {fabServices.map((svc, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="group bg-white border border-[#E5E7EB] overflow-hidden hover:border-[#1317E4]/40 transition-colors duration-300">
                  <div className="h-36 overflow-hidden">
                    <img src={svc.img} alt={svc.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                  </div>
                  <div className="p-4 flex items-center gap-2">
                    <svc.icon size={16} className="text-[#1317E4]" />
                    <p className="text-sm font-medium text-[#111111]">{svc.title}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal>
            <div className="mt-8">
              <Link href="/engineering" className="btn-brand btn-brand-outline inline-flex items-center gap-2">
                {t("home.eng.cta")}
                <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ─── Case Studies ─── */}
      <section className="bg-white py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("cases.label")}</p>
            <h2 className="mt-4 text-[clamp(2rem,5vw,3.5rem)] leading-[1.05] text-[#111111] whitespace-pre-line" style={{ fontFamily: "var(--font-heading)" }}>
              {t("cases.heading")}
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-14">
            {[
              { industry: "cases.c1.industry", tag: "cases.c1.tag", title: "cases.c1.title", challenge: "cases.c1.challenge", outcome: "cases.c1.outcome", stat1n: "cases.c1.stat1.num", stat1l: "cases.c1.stat1.label", stat2n: "cases.c1.stat2.num", stat2l: "cases.c1.stat2.label" },
              { industry: "cases.c2.industry", tag: "cases.c2.tag", title: "cases.c2.title", challenge: "cases.c2.challenge", outcome: "cases.c2.outcome", stat1n: "cases.c2.stat1.num", stat1l: "cases.c2.stat1.label", stat2n: "cases.c2.stat2.num", stat2l: "cases.c2.stat2.label" },
              { industry: "cases.c3.industry", tag: "cases.c3.tag", title: "cases.c3.title", challenge: "cases.c3.challenge", outcome: "cases.c3.outcome", stat1n: "cases.c3.stat1.num", stat1l: "cases.c3.stat1.label", stat2n: "cases.c3.stat2.num", stat2l: "cases.c3.stat2.label" },
            ].map((c, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="bg-white border border-[#E5E7EB] p-8 flex flex-col hover:border-[#1317E4]/40 transition-colors duration-300 h-full">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-xs tracking-widest text-[#6B7280] uppercase">{t(c.industry)}</span>
                    <span className="text-xs tracking-widest text-[#1317E4] bg-[#1317E4]/10 px-2 py-0.5">{t(c.tag)}</span>
                  </div>
                  <h3 className="text-lg font-bold text-[#111111] leading-snug mb-5" style={{ fontFamily: "var(--font-heading)" }}>
                    {t(c.title)}
                  </h3>
                  <div className="mb-5">
                    <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-2">{lang === "en" ? "Challenge" : "挑战"}</p>
                    <p className="text-sm text-[#6B7280] leading-relaxed">{t(c.challenge)}</p>
                  </div>
                  <div className="mb-6">
                    <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-2">{lang === "en" ? "Outcome" : "成果"}</p>
                    <p className="text-sm text-[#111111]/70 leading-relaxed">{t(c.outcome)}</p>
                  </div>
                  <div className="mt-auto grid grid-cols-2 gap-4 pt-6 border-t border-[#E5E7EB]">
                    <div>
                      <p className="text-2xl font-bold text-[#1317E4]">{t(c.stat1n)}</p>
                      <p className="text-xs text-[#6B7280] mt-1">{t(c.stat1l)}</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-[#1317E4]">{t(c.stat2n)}</p>
                      <p className="text-xs text-[#6B7280] mt-1">{t(c.stat2l)}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <p className="mt-8 text-xs text-[#6B7280]/50 text-center">{t("cases.sub")}</p>
        </div>
      </section>

      {/* ─── CTA Banner ─── */}
      <section className="bg-[#111111] py-20">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("contact.heading").replace("\n", " ")}
            </h2>
            <p className="mt-4 text-white/50 text-lg max-w-lg mx-auto">
              {t("contact.sub")}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link href="/contact" className="btn-brand btn-brand-filled inline-flex items-center gap-2">
                {t("hero.cta")}
                <ArrowRight size={16} />
              </Link>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2"
              >
                <MessageCircle size={16} />
                {t("hero.whatsapp")}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
