import { useEffect } from "react";
import { useLang } from "@/contexts/LanguageContext";
import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { motion } from "framer-motion";
import {
  ArrowRight, AlertTriangle, Lock, Users, Wrench, Eye, Shield, Zap,
  Package, Factory, ClipboardList, CheckCircle, Settings, Gauge,
  MessageCircle,
} from "lucide-react";
import { Link } from "wouter";

const HERO_VIDEO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/bps_hero_video_234c57ec.mp4";
const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%20need%20help%20with%20my%20ERP%20system...";

export default function ERPRescue() {
  const { t, lang } = useLang();

  useEffect(() => {
    document.title = lang === "en"
      ? "ERP Rescue | Fix Your Broken ERP — Velo Working"
      : "ERP拯救 | 修复您失败的ERP — Velo Working";
    document.querySelector('meta[name="description"]')?.setAttribute(
      "content",
      lang === "en"
        ? "We rescue broken ERP implementations for manufacturing SMEs. Fixed scope, fixed price. No vendor lock-in. Singapore."
        : "我们为制造业中小企业拯救失败的ERP实施。固定范围，固定价格。无供应商锁定。新加坡。"
    );
  }, [lang]);

  const failures = [
    { icon: Lock, titleKey: "erp.fail1.title", descKey: "erp.fail1.desc" },
    { icon: Users, titleKey: "erp.fail2.title", descKey: "erp.fail2.desc" },
    { icon: AlertTriangle, titleKey: "erp.fail3.title", descKey: "erp.fail3.desc" },
  ];

  const diffs = [
    { icon: Wrench, titleKey: "erp.d1.title", descKey: "erp.d1.desc" },
    { icon: Eye, titleKey: "erp.d2.title", descKey: "erp.d2.desc" },
    { icon: Shield, titleKey: "erp.d3.title", descKey: "erp.d3.desc" },
    { icon: Users, titleKey: "erp.d4.title", descKey: "erp.d4.desc" },
  ];

  const steps = [
    { num: "01", titleKey: "erp.step1.title", descKey: "erp.step1.desc" },
    { num: "02", titleKey: "erp.step2.title", descKey: "erp.step2.desc" },
    { num: "03", titleKey: "erp.step3.title", descKey: "erp.step3.desc" },
    { num: "04", titleKey: "erp.step4.title", descKey: "erp.step4.desc" },
  ];

  const modules = [
    { icon: Settings, titleKey: "erp.mod1.title", descKey: "erp.mod1.desc" },
    { icon: Package, titleKey: "erp.mod2.title", descKey: "erp.mod2.desc" },
    { icon: Factory, titleKey: "erp.mod3.title", descKey: "erp.mod3.desc" },
    { icon: ClipboardList, titleKey: "erp.mod4.title", descKey: "erp.mod4.desc" },
    { icon: Gauge, titleKey: "erp.mod5.title", descKey: "erp.mod5.desc" },
  ];

  const comparisonRows = lang === "en"
    ? [
        ["Bundle licence + hosting + implementation into one expensive bill", "Affordable platform subscription + labour-only implementation"],
        ["Sell the system and walk away after go-live", "Stay on retainer until the team owns it"],
        ["Quote open-ended time-and-materials", "Fixed scope, fixed price — no surprises"],
        ["Send generalist IT consultants who've never seen a factory", "Send an engineer who's wired control panels and walked production floors"],
        ["Lock clients into proprietary platforms", "Vendor-neutral. Zero dependency."],
      ]
    : [
        ["将许可+托管+实施捆绑成一张昂贵的账单", "经济实惠的平台订阅 + 纯劳务实施"],
        ["卖完系统上线后就走人", "持续支持直到团队完全掌握"],
        ["报价开放式工时费", "固定范围，固定价格 — 没有意外"],
        ["派来从没见过工厂的通用IT顾问", "派来亲手接过控制面板线的工程师"],
        ["把客户锁定在专有平台上", "供应商中立。零依赖。"],
      ];

  return (
    <Layout>
      {/* ─── Hero ─── */}
      <section className="relative bg-[#111111] py-24 lg:py-32 overflow-hidden">
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover opacity-30" src={HERO_VIDEO} />
        <div className="absolute inset-0 bg-[#111111]/60" />
        <div className="container relative z-10">
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="section-label !text-white">
            {t("erp.page.label")}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="mt-4 text-[clamp(2.5rem,5vw,4rem)] leading-[1.1] text-white whitespace-pre-line max-w-3xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("erp.page.heading")}
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-[clamp(0.9375rem,2vw,1.125rem)] text-white/50 leading-relaxed max-w-xl"
          >
            {t("erp.page.intro")}
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.3 }} className="mt-8">
            <Link href="/contact" className="btn-brand btn-brand-filled inline-flex items-center gap-2">
              {t("erp.cta")}
              <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ─── Three Structural Failures ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("erp.problem.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight max-w-3xl" style={{ fontFamily: "var(--font-heading)" }}>
              {t("erp.problem.heading")}
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            {failures.map((f, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="border border-[#E5E7EB] p-8 h-full hover:border-[#DC2626]/40 transition-colors duration-300">
                  <f.icon size={28} className="text-[#DC2626] mb-5" />
                  <h3 className="text-base font-bold text-[#111111] mb-3" style={{ fontFamily: "var(--font-heading)" }}>{t(f.titleKey)}</h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{t(f.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Comparison Table ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container max-w-4xl">
          <Reveal>
            <p className="section-label">{t("erp.diff.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("erp.diff.heading")}
            </h2>
          </Reveal>

          <div className="mt-12 overflow-hidden border border-[#E5E7EB]">
            <div className="grid grid-cols-2 bg-[#111111]">
              <div className="px-6 py-4 text-sm font-bold text-white/80 tracking-wide uppercase">{lang === "en" ? "What Others Do" : "别人怎么做"}</div>
              <div className="px-6 py-4 text-sm font-bold text-[#1317E4] tracking-wide uppercase border-l border-white/10">{lang === "en" ? "What Velo Working Does" : "Velo Working 怎么做"}</div>
            </div>
            {comparisonRows.map((row, i) => (
              <div key={i} className={`grid grid-cols-2 ${i < comparisonRows.length - 1 ? "border-b border-[#E5E7EB]" : ""}`}>
                <div className="px-6 py-5 text-sm text-[#6B7280] leading-relaxed">{row[0]}</div>
                <div className="px-6 py-5 text-sm text-[#111111] leading-relaxed border-l border-[#E5E7EB] font-medium">{row[1]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Detailed Differentiators ─── */}
      <section className="bg-[#111111] py-20 lg:py-28">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {diffs.map((d, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="border border-white/10 p-8 hover:border-[#1317E4]/40 transition-colors duration-300">
                  <d.icon size={24} className="text-[#1317E4] mb-4" />
                  <h3 className="text-lg font-bold text-white mb-3" style={{ fontFamily: "var(--font-heading)" }}>{t(d.titleKey)}</h3>
                  <p className="text-sm text-white/50 leading-relaxed">{t(d.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── How It Works — 4 Steps ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("erp.how.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight whitespace-pre-line" style={{ fontFamily: "var(--font-heading)" }}>
              {t("erp.how.heading")}
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-14">
            {steps.map((step, i) => (
              <Reveal key={step.num} delay={i * 0.1}>
                <div className="relative">
                  <span className="text-6xl font-bold text-[#1317E4]/10 leading-none block" style={{ fontFamily: "var(--font-heading)" }}>
                    {step.num}
                  </span>
                  <div className="mt-1">
                    <div className="w-10 h-[3px] bg-[#1317E4] mb-3" />
                    <h3 className="text-base font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>{t(step.titleKey)}</h3>
                    <p className="mt-2 text-sm text-[#6B7280] leading-relaxed">{t(step.descKey)}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── What We Cover — Modules ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("erp.modules.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight whitespace-pre-line max-w-2xl" style={{ fontFamily: "var(--font-heading)" }}>
              {t("erp.modules.heading")}
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-12">
            {modules.map((mod, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className="bg-white border border-[#E5E7EB] p-7 h-full hover:border-[#1317E4]/40 transition-colors duration-300">
                  <div className="w-11 h-11 border-2 border-[#1317E4] flex items-center justify-center mb-5">
                    <mod.icon size={20} className="text-[#1317E4]" />
                  </div>
                  <h3 className="text-base font-bold text-[#111111] mb-2" style={{ fontFamily: "var(--font-heading)" }}>{t(mod.titleKey)}</h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{t(mod.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Before / After ─── */}
      <section className="bg-[#111111] py-20 lg:py-28">
        <div className="container max-w-3xl text-center">
          <Reveal>
            <p className="text-xs tracking-[0.3em] uppercase text-white/40 mb-4">{lang === "en" ? "The Outcome" : "成果"}</p>
            <h2 className="text-[clamp(1.6rem,3.5vw,2.5rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en"
                ? "For the first time in years, the owner opens one screen and sees everything."
                : "多年来第一次，老板打开一个屏幕就能看到一切。"}
            </h2>
            <p className="mt-6 text-base text-white/50 leading-relaxed max-w-xl mx-auto">
              {lang === "en"
                ? "Inventory, production, deliveries — all in one place. No calling the admin. No opening Excel. No WhatsApping the supervisor. The system is theirs. Not the vendor's. Not ours."
                : "库存、生产、交付 — 全部在一个地方。不用打电话给行政。不用打开Excel。不用WhatsApp主管。系统是他们的。不是供应商的。不是我们的。"}
            </p>
          </Reveal>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="bg-[#1317E4] py-16">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("erp.cta")}
            </h2>
            <p className="mt-4 text-white/70 text-lg max-w-lg mx-auto">
              {lang === "en"
                ? "We'll walk your floor, audit your system, and tell you exactly what's broken — for free. No obligation."
                : "我们会走您的车间、诊断您的系统，并准确告诉您哪里出了问题 — 完全免费。无任何义务。"}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link href="/contact" className="btn-brand btn-brand-white inline-flex items-center gap-2">
                {t("erp.cta")}
                <ArrowRight size={16} />
              </Link>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
                className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2">
                <MessageCircle size={16} />
                {t("hero.whatsapp")}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
