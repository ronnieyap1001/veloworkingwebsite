import { useLang } from "@/contexts/LanguageContext";
import { Link } from "wouter";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/velo-logo-dark_615c188b.png";
const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working...";

const navItems = [
  { key: "nav.erp", href: "/erp-rescue" },
  { key: "nav.engineering", href: "/engineering" },
  { key: "nav.about", href: "/about" },
  { key: "nav.contact", href: "/contact" },
];

export default function Footer() {
  const { t, lang } = useLang();
  const year = new Date().getFullYear();

  return (
    <footer className="bg-[#111111] border-t border-white/5">
      <div className="container py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Logo + Tagline */}
          <div>
            <Link href="/" className="flex items-center gap-3 hover:opacity-70 transition-opacity">
              <img src={LOGO_URL} alt="Velo Working" className="w-7 h-7 object-contain brightness-0 invert" />
              <span className="text-sm font-bold tracking-tight text-white" style={{ fontFamily: "var(--font-body)" }}>
                VELO WORKING
              </span>
            </Link>
            <p className="mt-4 text-sm text-white/30 italic" style={{ fontFamily: "var(--font-heading)" }}>
              {t("footer.tagline")}
            </p>
          </div>

          {/* Navigation */}
          <div>
            <p className="text-xs text-white/30 uppercase tracking-widest mb-4">
              {lang === "en" ? "Navigation" : "导航"}
            </p>
            <nav className="flex flex-col gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.key}
                  href={item.href}
                  className="text-sm text-white/50 hover:text-white transition-colors"
                >
                  {t(item.key)}
                </Link>
              ))}
            </nav>
          </div>

          {/* Contact */}
          <div>
            <p className="text-xs text-white/30 uppercase tracking-widest mb-4">
              {lang === "en" ? "Contact" : "联系"}
            </p>
            <div className="flex flex-col gap-2 text-sm text-white/50">
              <a href="mailto:sales@veloworking.com" className="hover:text-white transition-colors">
                sales@veloworking.com
              </a>
              <a href="tel:+6598943004" className="hover:text-white transition-colors">
                +65 9894 3004
              </a>
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                WhatsApp
              </a>
              <p className="mt-2 text-xs text-white/20 leading-relaxed">
                540 Sims Ave, #03-05<br />Singapore 387603
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-3">
          <p className="text-xs text-white/20">
            © {year} Velo Working Pte. Ltd. (UEN: 202609930G). {t("footer.rights")}
          </p>
        </div>
      </div>
    </footer>
  );
}
