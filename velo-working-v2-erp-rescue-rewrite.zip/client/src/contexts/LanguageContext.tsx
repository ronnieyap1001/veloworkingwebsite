import { createContext, useContext, useState, type ReactNode } from "react";

type Lang = "en" | "zh";

interface LanguageContextType {
  lang: Lang;
  toggleLang: () => void;
  t: (key: string) => string;
}

const translations: Record<string, Record<Lang, string>> = {
  // ─── Navigation ───────────────────────────────────────────────
  "nav.home":        { en: "Home",                  zh: "首页" },
  "nav.erp":         { en: "ERP Rescue",            zh: "ERP 拯救" },
  "nav.engineering": { en: "Fabrication",            zh: "制造服务" },
  "nav.about":       { en: "About",                 zh: "关于" },
  "nav.contact":     { en: "Contact",               zh: "联系" },

  // ─── Hero ─────────────────────────────────────────────────────
  "hero.label": {
    en: "ERP Rescue · Fabrication & Assembly",
    zh: "ERP拯救 · 制造与装配",
  },
  "hero.heading": {
    en: "Your ERP Sits Unused.\nWe Fix That.",
    zh: "您的ERP闲置未用。\n我们来修复。",
  },
  "hero.sub": {
    en: "We rescue broken ERP systems, set up new ones from scratch, and provide the skilled implementation labour that makes digital transformation actually work on the factory floor.",
    zh: "我们拯救失败的ERP系统，从零开始搭建新系统，并提供熟练的实施劳动力，让数字化转型在工厂车间真正落地。",
  },
  "hero.whatsapp": { en: "WhatsApp Us",  zh: "WhatsApp 联系" },
  "hero.cta":      { en: "Book a Free ERP Audit", zh: "预约免费ERP诊断" },

  // ─── Home — Why Digital Systems ───────────────────────────────
  "home.why.label":   { en: "The Reality",            zh: "现实" },
  "home.why.heading": { en: "Stop Finding Out\nProblems Too Late.", zh: "别再等问题\n爆发才发现。" },
  "home.why.desc": {
    en: "Every factory generates thousands of data points daily — how long each job takes, which supplier delivers late, which batch has higher rejection rates. Most of this data is never captured. It lives in a supervisor's head, a WhatsApp message that scrolls past, an Excel file nobody opens. Every decision without it is a guess.",
    zh: "每家工厂每天产生数千个数据点 — 每项工作需要多长时间、哪家供应商交货延迟、哪个批次的退货率更高。大部分数据从未被记录。它存在于主管的脑海中、一条被刷过的WhatsApp消息里、一个没人打开的Excel文件中。没有这些数据，每个决策都是猜测。",
  },

  "home.why.col1.title": { en: "The \"Loudest Voice\" Problem", zh: "\"谁声音大谁优先\"的问题" },
  "home.why.col1.desc": {
    en: "Without a system, work gets prioritised by whoever shouts loudest. The customer who calls most gets served first — not the most urgent or profitable order. A digital system replaces personality-driven chaos with a framework.",
    zh: "没有系统，工作按谁声音最大来排优先级。打电话最多的客户先被服务 — 而不是最紧急或最有利润的订单。数字系统用框架取代人情驱动的混乱。",
  },
  "home.why.col2.title": { en: "The \"Excel Wizard\" Risk", zh: "\"Excel大师\"的风险" },
  "home.why.col2.desc": {
    en: "One admin holds your entire operation's data in their head and their laptop. When they leave, the system dies with them. A proper system turns tribal knowledge into shared knowledge — accessible to anyone.",
    zh: "一个行政人员将整个公司的运营数据记在脑子里和电脑里。当他们离职时，系统随之崩溃。一个合理的系统将个人经验转化为共享知识 — 任何人都可以查阅。",
  },
  "home.why.col3.title": { en: "The AI Era Runs on Data", zh: "AI时代靠数据运行" },
  "home.why.col3.desc": {
    en: "AI can forecast demand, optimise inventory, and predict machine failures — but only with structured digital data. A factory on Excel and WhatsApp cannot use AI. Your ERP is the data foundation that makes AI possible.",
    zh: "AI可以预测需求、优化库存、预判设备故障 — 但前提是有结构化的数字数据。靠Excel和WhatsApp运行的工厂无法使用AI。ERP是让AI成为可能的数据基础。",
  },

  // ─── Home — Who We Help (5 Profiles) ──────────────────────────
  "home.profiles.label":   { en: "Who We Help",               zh: "我们帮助谁" },
  "home.profiles.heading": { en: "Which One Are You?",         zh: "您属于哪一种？" },
  "home.profiles.sub": {
    en: "We serve manufacturing and industrial SMEs across five common situations.",
    zh: "我们服务于五种常见困境中的制造业中小企业。",
  },

  "home.p1.title": { en: "\"We paid for ERP but nobody uses it.\"", zh: "\"我们花钱买了ERP，但没人用。\"" },
  "home.p1.desc": {
    en: "You spent good money on a system 1–3 years ago. It's installed, but staff bypass it for Excel, only 2–3 modules are active, and the vendor stopped answering calls. We rescue what's already there — reconfigure it to match your actual floor, retrain staff on their real daily tasks.",
    zh: "您在1-3年前花了不少钱买了一套系统。系统已安装，但员工绕过它用Excel，只有2-3个模块在使用，供应商也不再接电话了。我们拯救现有系统 — 重新配置以匹配实际车间，按员工的真实日常任务重新培训。",
  },

  "home.p2.title": { en: "\"We're still running on Excel and WhatsApp.\"", zh: "\"我们还在用Excel和WhatsApp。\"" },
  "home.p2.desc": {
    en: "You know you need a system but the options are confusing and expensive. We start with the 2–3 modules that hurt most — usually inventory, purchasing, and production — not everything at once.",
    zh: "您知道需要一个系统，但选择太多、太贵。我们从最痛的2-3个模块开始 — 通常是库存、采购和生产 — 而不是一次性全部上线。",
  },

  "home.p3.title": { en: "\"We're growing fast and everything is breaking.\"", zh: "\"我们增长很快，但一切都在崩溃。\"" },
  "home.p3.desc": {
    en: "Revenue is up but operations are cracking — errors increasing, deliveries slipping, inventory discrepancies multiplying. Your people are maxed out. We do the implementation work so they don't have to.",
    zh: "营收在增长但运营正在裂开 — 错误增加、交货延迟、库存差异倍增。您的员工已经满负荷。我们来做实施工作，这样他们不用分心。",
  },

  "home.p4.title": { en: "\"We're overpaying and feel trapped.\"", zh: "\"我们付太多钱了，感觉被困住了。\"" },
  "home.p4.desc": {
    en: "You're paying thousands per month for hosting, licences, and \"support\" from a vendor who bundled everything. We migrate you to an affordable platform with zero data loss. Your annual cost drops dramatically.",
    zh: "您每月付数千元给一个捆绑了所有服务的供应商，用于托管、许可和所谓的\"支持\"。我们帮您迁移到经济实惠的平台，零数据丢失。年度成本大幅下降。",
  },

  "home.p5.title": { en: "\"We want to be ready for AI but have no data.\"", zh: "\"我们想为AI做准备，但没有数据。\"" },
  "home.p5.desc": {
    en: "You see AI transforming manufacturing globally and want to prepare. We implement ERP as your data foundation. Every transaction logged today becomes a data point AI can learn from tomorrow.",
    zh: "您看到AI正在改变全球制造业，想做好准备。我们实施ERP作为您的数据基础。今天记录的每一笔交易，都将成为AI未来可以学习的数据点。",
  },

  // ─── Home — What Sets Us Apart ────────────────────────────────
  "home.diff.label":   { en: "Why Velo Working",     zh: "为什么选择 Velo Working" },
  "home.diff.heading": { en: "What Makes Us Different", zh: "我们有何不同" },

  "home.diff1.title": { en: "We've Wired the Panels", zh: "我们亲手接过线" },
  "home.diff1.desc": {
    en: "We come from fabrication — control panels, wire harnesses, PCBA. When we configure your system, we're not guessing how your factory works. We've built the hardware.",
    zh: "我们出身制造业 — 控制面板、线束、PCBA。当我们配置您的系统时，不是在猜测工厂如何运作。我们亲手组装过硬件。",
  },
  "home.diff2.title": { en: "Fixed Scope, Fixed Price", zh: "固定范围，固定价格" },
  "home.diff2.desc": {
    en: "No open-ended billing. No uncapped time-and-materials. You know exactly what you're paying for before we start. The #1 reason SMEs don't digitalize is fear of an uncapped bill. We remove that on day one.",
    zh: "没有开放式账单。没有无上限的工时费。开始之前您就确切知道要付多少。中小企业不数字化的首要原因是怕账单无上限。我们第一天就消除这个顾虑。",
  },
  "home.diff3.title": { en: "We Stay After Go-Live", zh: "上线后我们不会消失" },
  "home.diff3.desc": {
    en: "ERP adoption happens in the first 90 days of daily use — exactly when most vendors disappear. We sit with your staff, fix what breaks in real time, and adjust workflows until the system sticks.",
    zh: "ERP的真正落地发生在日常使用的前90天 — 恰恰是大多数供应商消失的时候。我们和您的员工坐在一起，实时修复问题，调整工作流程直到系统稳定运行。",
  },

  // ─── Home — Fabrication Section ───────────────────────────────
  "home.eng.label":   { en: "Fabrication & Assembly",  zh: "制造与装配" },
  "home.eng.heading": { en: "Our Credibility Is\nBuilt on Hardware.", zh: "我们的信誉\n建立在硬件之上。" },
  "home.eng.desc": {
    en: "We maintain in-house fabrication capability — control panels, wire harnesses, PCBA, and metal fabrication. This isn't a separate business. It's proof that we understand the physical reality of manufacturing. It's also how we serve clients who need both systems and hardware from a single trusted partner.",
    zh: "我们拥有内部制造能力 — 控制面板、线束、PCBA和金属加工。这不是一个独立的业务线。它证明我们理解制造业的物理现实。这也是我们为需要系统和硬件一站式服务的客户提供服务的方式。",
  },
  "home.eng.cta": { en: "Explore Fabrication Services", zh: "了解制造服务" },

  // ─── Home — Case Studies ──────────────────────────────────────
  "cases.label":   { en: "Case Studies",                    zh: "案例研究" },
  "cases.heading": { en: "Real Results.\nReal Factories.",   zh: "真实成果。\n真实工厂。" },
  "cases.sub": {
    en: "Client names withheld for confidentiality. Results are representative of actual project outcomes.",
    zh: "客户名称因保密要求不予披露。成果数据均来自实际项目。",
  },

  "cases.c1.industry": { en: "Precision Machining",  zh: "精密加工" },
  "cases.c1.tag":      { en: "ERP Rescue", zh: "ERP拯救" },
  "cases.c1.title": {
    en: "Rescued an abandoned ERP — order processing time dropped 60%",
    zh: "拯救废弃ERP — 订单处理时间缩短60%",
  },
  "cases.c1.challenge": {
    en: "A 45-person shop spent S$65K on ERP. Two years later, only 2 of 12 modules were used. Staff bypassed it for Excel. The vendor charged S$2,500/month and took 5 days to respond to tickets.",
    zh: "一家45人的车间在ERP上花了S$65K。两年后，12个模块中只有2个在使用。员工绕过系统用Excel。供应商每月收S$2,500，工单响应需要5天。",
  },
  "cases.c1.outcome": {
    en: "We reconfigured 4 core modules to match the actual floor, cleaned the inventory database, and retrained staff on their real daily tasks. Hosted moved to the client's own cloud at S$25/month. System went from 2 modules to 8. Inventory accuracy jumped to 95%+.",
    zh: "我们重新配置了4个核心模块以匹配实际车间，清理了库存数据库，并按员工的真实日常任务重新培训。托管迁移到客户自己的云端，每月S$25。系统从2个模块增加到8个。库存准确率跃升至95%以上。",
  },
  "cases.c1.stat1.num":   { en: "60%",   zh: "60%" },
  "cases.c1.stat1.label": { en: "Faster order processing", zh: "订单处理提速" },
  "cases.c1.stat2.num":   { en: "8 wks", zh: "8周" },
  "cases.c1.stat2.label": { en: "Full rescue",             zh: "完整拯救" },

  "cases.c2.industry": { en: "Sheet Metal Fabrication", zh: "钣金制造" },
  "cases.c2.tag":      { en: "MES Integration", zh: "MES集成" },
  "cases.c2.title": {
    en: "Connected shop-floor machines to management dashboards — downtime cut 35%",
    zh: "将车间设备连接至管理仪表盘 — 停机时间减少35%",
  },
  "cases.c2.challenge": {
    en: "Zero real-time visibility into machine utilisation. Supervisors relied on manual floor walks. Bottlenecks were only discovered after delays had already cascaded.",
    zh: "对设备利用率完全没有实时可见性。主管依赖人工巡检。瓶颈往往在延误波及整个排程后才被发现。",
  },
  "cases.c2.outcome": {
    en: "We implemented a shop-floor MES connected to the existing system. Real-time OEE dashboards replaced manual reporting. Supervisors could respond to stoppages within minutes.",
    zh: "我们部署了与现有系统相连的车间MES。实时OEE仪表盘取代了人工报告。主管可在数分钟内响应停机。",
  },
  "cases.c2.stat1.num":   { en: "35%",   zh: "35%" },
  "cases.c2.stat1.label": { en: "Less downtime",       zh: "停机减少" },
  "cases.c2.stat2.num":   { en: "Live",  zh: "实时" },
  "cases.c2.stat2.label": { en: "OEE visibility",      zh: "OEE可见性" },

  "cases.c3.industry": { en: "Process Engineering", zh: "过程工程" },
  "cases.c3.tag":      { en: "Fabrication", zh: "制造" },
  "cases.c3.title": {
    en: "Built 12 PLC control panels — delivered on time after two vendors failed",
    zh: "组装12套PLC控制面板 — 在两家供应商失败后按时交付",
  },
  "cases.c3.challenge": {
    en: "A systems integrator needed 12 custom PLC panels built, wired, tested, and connected to SCADA for a commissioning deadline. Two previous vendors had failed to deliver.",
    zh: "一家系统集成商需要在投产截止日期前完成12套定制PLC面板的组装、接线、测试和SCADA连接。两家供应商已失败。",
  },
  "cases.c3.outcome": {
    en: "We completed all 12 panels on schedule with full FAT documentation. Zero rework post-installation. The client has since engaged us for ongoing site maintenance.",
    zh: "我们按时完成全部12套面板，附完整FAT文件。安装后零返工。客户此后持续委托我们进行现场维护。",
  },
  "cases.c3.stat1.num":   { en: "12",     zh: "12" },
  "cases.c3.stat1.label": { en: "Panels delivered on time", zh: "按时交付面板" },
  "cases.c3.stat2.num":   { en: "0",      zh: "0" },
  "cases.c3.stat2.label": { en: "Rework incidents",         zh: "返工事故" },

  // ─── ERP Rescue Page ──────────────────────────────────────────
  "erp.page.label":   { en: "ERP Rescue",                 zh: "ERP拯救" },
  "erp.page.heading": { en: "The Way ERP Is Sold\nIn This Market Is Broken.", zh: "这个市场上\nERP的销售方式已经坏了。" },
  "erp.page.intro": {
    en: "Singapore's manufacturing SMEs know they need to digitalize. 96% report some digital tool use. Government grants cover up to 80%. The intent is there. The money is available. But 60% of SMEs are still in the beginning stages. Most factories still run on Excel, WhatsApp, and paper.",
    zh: "新加坡的制造业中小企业知道他们需要数字化。96%的企业报告使用了一些数字工具。政府补贴覆盖高达80%。意愿是有的。钱也是有的。但60%的中小企业仍在起步阶段。大多数工厂仍在用Excel、WhatsApp和纸质表格运营。",
  },

  "erp.problem.label":   { en: "The Real Problem",        zh: "真正的问题" },
  "erp.problem.heading": { en: "Three Structural Failures", zh: "三个结构性失败" },

  "erp.fail1.title": { en: "Vendor Lock-In", zh: "供应商锁定" },
  "erp.fail1.desc": {
    en: "Traditional vendors bundle licence + hosting + implementation into one recurring bill. The client pays forever, owns nothing, and can't leave. When the vendor underdelivers, the switching cost is so high that the client just tolerates a broken system.",
    zh: "传统供应商将许可证+托管+实施捆绑成一张循环账单。客户永远付费，什么都不拥有，也无法离开。当供应商交付不足时，切换成本太高，客户只能忍受一个坏掉的系统。",
  },
  "erp.fail2.title": { en: "No Factory Understanding", zh: "不懂工厂" },
  "erp.fail2.desc": {
    en: "Most ERP consultants come from IT backgrounds. They know databases. They don't know how a control panel is wired, how a warehouse physically flows, or what a production supervisor actually needs on screen. They configure based on demos, not floor reality.",
    zh: "大多数ERP顾问来自IT背景。他们懂数据库。但不知道控制面板如何接线、仓库物理流转如何运作、生产主管实际需要在屏幕上看到什么。他们基于演示配置，而不是车间现实。",
  },
  "erp.fail3.title": { en: "Nobody Stays After Go-Live", zh: "上线后无人留守" },
  "erp.fail3.desc": {
    en: "ERP adoption happens in the first 90 days of daily use, when staff hit problems, when data doesn't reconcile, when workarounds pile up. That's exactly when the vendor is gone.",
    zh: "ERP落地发生在日常使用的前90天，当员工遇到问题时、当数据对不上时、当临时方案堆积时。恰恰这时候供应商已经走了。",
  },

  // ─── ERP Rescue — How We're Different ─────────────────────────
  "erp.diff.label":   { en: "Our Approach",              zh: "我们的方法" },
  "erp.diff.heading": { en: "What Makes Velo Working\nDifferent From Every\nOther ERP Player.", zh: "Velo Working\n与其他所有ERP服务商\n有何不同。" },

  "erp.d1.title": { en: "We've Built the Hardware", zh: "我们亲手组装过硬件" },
  "erp.d1.desc": {
    en: "Every ERP consultant in Singapore comes from IT. They learned ERP from documentation. We've physically built control panels, pulled wire harnesses, and touched the machines. When we configure your system, we know where the physical bins are and how parts actually move.",
    zh: "新加坡每一个ERP顾问都来自IT行业。他们从文档中学习ERP。我们亲手组装过控制面板、拉过线束、触摸过机器。当我们配置您的系统时，我们知道物理料仓在哪里，零件实际如何流转。",
  },
  "erp.d2.title": { en: "Zero Conflict of Interest", zh: "零利益冲突" },
  "erp.d2.desc": {
    en: "We don't earn commissions from any platform vendor. When we tell you \"your current system is fine, the configuration is wrong\" — that's an honest diagnosis, not a sales pitch.",
    zh: "我们不从任何平台供应商获取佣金。当我们告诉您\"您现有系统没问题，是配置有误\" — 这是诚实的诊断，不是推销话术。",
  },
  "erp.d3.title": { en: "The Person Who Sells Is the Person Who Delivers", zh: "卖的人就是做的人" },
  "erp.d3.desc": {
    en: "No handoff from sales to junior consultant. The same engineer who audits your floor, writes the proposal, configures the system, and trains your staff — is the same person throughout.",
    zh: "没有从销售到初级顾问的交接。审核您车间的工程师、写方案的人、配置系统的人、培训员工的人 — 始终是同一个人。",
  },
  "erp.d4.title": { en: "Your Team Is Already Stretched", zh: "您的团队已经满负荷" },
  "erp.d4.desc": {
    en: "You can't hire a full-time ERP person for a 3–6 month project, and you can't pull your ops manager off their work. We come in, do the implementation, train your staff on their specific daily tasks, and leave when it's stable. Zero disruption.",
    zh: "您不可能为3-6个月的项目雇一个全职ERP人员，也不可能把运营经理从工作中抽走。我们进来做实施，按具体日常任务培训员工，稳定后离开。零干扰。",
  },

  // ─── ERP Rescue — How It Works ────────────────────────────────
  "erp.how.label":   { en: "How It Works",              zh: "流程" },
  "erp.how.heading": { en: "From Broken System to\nWorking Factory in 8 Weeks.", zh: "从坏掉的系统到\n正常运转的工厂，8周。" },

  "erp.step1.title": { en: "The Audit (Free)", zh: "诊断（免费）" },
  "erp.step1.desc": {
    en: "We walk your factory floor — not your server room. We watch how parts move, how orders flow, where paper piles up. We map the gap between how your factory actually works and how the system was configured.",
    zh: "我们走的是您的工厂车间 — 不是服务器机房。我们观察零件如何流转、订单如何流动、纸质材料在哪里堆积。我们梳理工厂实际运作方式与系统配置之间的差距。",
  },
  "erp.step2.title": { en: "The Fix (Fixed Scope, Fixed Price)", zh: "修复（固定范围，固定价格）" },
  "erp.step2.desc": {
    en: "We reconfigure core modules, clean your data, set up workflows that match how your team actually operates, and retrain staff — not in a classroom, but on their actual daily tasks.",
    zh: "我们重新配置核心模块，清理数据，搭建与团队实际操作匹配的工作流，并重新培训员工 — 不是在教室里，而是在他们的实际日常任务上。",
  },
  "erp.step3.title": { en: "Stabilisation", zh: "稳定期" },
  "erp.step3.desc": {
    en: "We don't leave after configuration. We're on-site, sitting with your staff as they use the system. We fix what breaks in real time and adjust workflows when something doesn't fit.",
    zh: "配置完成后我们不会离开。我们在现场，和员工一起使用系统。我们实时修复问题，调整不合适的工作流。",
  },
  "erp.step4.title": { en: "Handover", zh: "交接" },
  "erp.step4.desc": {
    en: "By the end, your team owns the system. They can run reports, adjust workflows, and add users without calling us. We're here for support if needed — but the system is yours.",
    zh: "最后，您的团队拥有这个系统。他们可以出报告、调整工作流、添加用户，无需联系我们。如需支持我们随时在 — 但系统是您的。",
  },

  "erp.cta": { en: "Book a Free ERP Audit", zh: "预约免费ERP诊断" },

  // ─── ERP Rescue — What We Cover ───────────────────────────────
  "erp.modules.label":   { en: "What We Cover",           zh: "覆盖范围" },
  "erp.modules.heading": { en: "Procurement to Production\nto Quality — Connected.", zh: "从采购到生产\n到质量 — 全面打通。" },

  "erp.mod1.title": { en: "ERP Core", zh: "ERP核心" },
  "erp.mod1.desc":  { en: "Sales, purchasing, invoicing, finance, multi-currency — the digital backbone of your operations.", zh: "销售、采购、开票、财务、多币种 — 运营的数字骨干。" },
  "erp.mod2.title": { en: "Inventory & Warehouse", zh: "库存与仓库" },
  "erp.mod2.desc":  { en: "Stock tracking, bin locations, barcode scanning, reorder automation, batch/serial tracking.", zh: "库存追踪、库位管理、条码扫描、自动补货、批次/序列号追踪。" },
  "erp.mod3.title": { en: "Manufacturing (MRP/MES)", zh: "制造（MRP/MES）" },
  "erp.mod3.desc":  { en: "BOM management, production orders, shop-floor tracking, OEE dashboards, downtime logging.", zh: "BOM管理、生产订单、车间追踪、OEE仪表盘、停机记录。" },
  "erp.mod4.title": { en: "Quality Management", zh: "质量管理" },
  "erp.mod4.desc":  { en: "Document control, NCR management, audit tracking, CAPA workflows, supplier quality rating.", zh: "文档控制、NCR管理、审核追踪、CAPA工作流、供应商质量评级。" },
  "erp.mod5.title": { en: "Product Lifecycle (PLM)", zh: "产品生命周期（PLM）" },
  "erp.mod5.desc":  { en: "Revision control, ECO workflows, BOM versioning, NPI tracking, drawing management.", zh: "版本控制、ECO工作流、BOM版本管理、NPI追踪、图纸管理。" },

  // ─── Fabrication & Assembly Page ──────────────────────────────
  "eng.page.label":   { en: "Fabrication & Assembly",  zh: "制造与装配" },
  "eng.page.heading": { en: "The Hands That\nBuild Your Hardware.", zh: "为您打造\n硬件的双手。" },
  "eng.page.intro": {
    en: "Our fabrication capability isn't a separate business — it's the foundation of our credibility. We've wired the panels, walked the floors, and built the hardware. This is why we configure ERP systems better than any pure software consultant.",
    zh: "我们的制造能力不是一个独立的业务线 — 它是我们信誉的基础。我们接过线、走过车间、组装过硬件。这就是为什么我们比任何纯软件顾问都更善于配置ERP系统。",
  },
  "eng.what.label":    { en: "What We Build",              zh: "我们制造什么" },
  "eng.metal.title":   { en: "Metal Fabrication",           zh: "金属加工" },
  "eng.metal.desc": {
    en: "Custom cutting, welding, bending, and finishing for structural and mechanical components. From single prototypes to production runs.",
    zh: "结构和机械部件的定制切割、焊接、弯曲和精加工。从单个原型到批量生产。",
  },
  "eng.box.title":   { en: "Control Panel Assembly",       zh: "控制面板装配" },
  "eng.box.desc": {
    en: "PLC, SCADA, and electrical control panels — component sourcing, wiring, integration, testing, and commissioning.",
    zh: "PLC、SCADA和电气控制面板 — 元件采购、接线、集成、测试和调试。",
  },
  "eng.pcba.title":   { en: "PCBA Assembly",               zh: "PCBA组装" },
  "eng.pcba.desc": {
    en: "SMT and through-hole component placement, precision soldering, and functional testing — built to your exact specifications.",
    zh: "SMT和通孔元件贴装、精密焊接和功能测试 — 完全按照您的规格制造。",
  },
  "eng.wire.title": { en: "Wire Harnessing",              zh: "线束加工" },
  "eng.wire.desc": {
    en: "Custom cable harness fabrication, connector assembly, and continuity testing. Every wire routed to your schematic.",
    zh: "定制电缆束制造、连接器组装和连通性测试。每根电线按照您的原理图布线。",
  },
  "eng.how.label":   { en: "Our Process",   zh: "我们的流程" },
  "eng.how.heading": { en: "From Raw Material to\nCommissioned System.",   zh: "从原材料到\n调试完成的系统。" },
  "eng.step1.title": { en: "Procurement",     zh: "采购" },
  "eng.step1.desc":  { en: "We source materials from trusted suppliers with verified quality certifications.", zh: "我们从具有质量认证的可信赖供应商处采购材料。" },
  "eng.step2.title": { en: "Planning",        zh: "规划" },
  "eng.step2.desc":  { en: "Detailed project planning — scope, timelines, resource allocation, quality checkpoints.", zh: "详细的项目规划 — 范围、时间表、资源分配、质量检查点。" },
  "eng.step3.title": { en: "Manufacturing",   zh: "制造" },
  "eng.step3.desc":  { en: "Cutting, welding, bending, machining — every process executed with precision.", zh: "切割、焊接、弯曲、加工 — 每个工序都经过精密执行。" },
  "eng.step4.title": { en: "Assembly & Test",  zh: "组装与测试" },
  "eng.step4.desc":  { en: "Wiring, mounting, integration, rigorous testing. Nothing leaves without passing QC.", zh: "接线、安装、集成、严格测试。未通过质量控制的产品不会出厂。" },
  "eng.cta": { en: "Start Your Project", zh: "开始您的项目" },

  // ─── About ────────────────────────────────────────────────────
  "about.label":   { en: "About Us",           zh: "关于我们" },
  "about.heading": { en: "Built for the Ones\nStill Standing.", zh: "为那些\n仍在坚持的人而建。" },
  "about.intro": {
    en: "Velo Working is a vendor-neutral ERP consulting firm built for manufacturing and industrial SMEs in Singapore. We rescue broken ERP implementations, set up new systems from scratch, and provide the skilled implementation labour that makes digital transformation actually work on the factory floor.",
    zh: "Velo Working 是一家面向新加坡制造业中小企业的供应商中立ERP咨询公司。我们拯救失败的ERP实施、从零搭建新系统，并提供让数字化转型在工厂车间真正落地的熟练实施劳动力。",
  },
  "about.founder": {
    en: "Founded by Ronnie Yap, Velo Working was built after observing a consistent pattern: local industrial SMEs are caught between overpriced vendors who underdeliver and overseas competitors who produce faster and cheaper. Most ERP implementations fail not because the software is wrong, but because nobody understood how the factory actually works.",
    zh: "由 Ronnie Yap 创立，Velo Working 源于一个持续观察到的规律：本地工业中小企业被夹在定价过高却交付不足的供应商和生产更快更便宜的海外竞争对手之间。大多数ERP实施的失败不是因为软件有问题，而是因为没有人真正理解工厂的实际运作方式。",
  },
  "about.mission": {
    en: "Our mission is to close the digitalization gap. Not by selling expensive software. By giving every manufacturing SME a working digital system — one they can afford, one they can maintain, and one that prepares them for the AI era.",
    zh: "我们的使命是缩小数字化差距。不是通过销售昂贵的软件。而是为每一家制造业中小企业提供一个可运作的数字系统 — 一个他们负担得起、可以自己维护、并为AI时代做好准备的系统。",
  },

  "about.values.label":    { en: "Our Beliefs",     zh: "我们的信念" },
  "about.value1.title":    { en: "Sincere",          zh: "真诚" },
  "about.value1.desc":     { en: "If a solution isn't right for you, we'll tell you. We'd rather lose a deal than deliver something that doesn't serve your actual needs.", zh: "如果一个方案不适合您，我们会直说。我们宁愿失去一笔交易，也不愿交付不符合您实际需求的东西。" },
  "about.value2.title":    { en: "Transparent",      zh: "透明" },
  "about.value2.desc":     { en: "You will always know where your project stands — costs, timelines, challenges, and progress. We share the full picture, even when it's not the easiest conversation.", zh: "您将始终了解项目进展 — 成本、时间线、挑战和进度。我们分享全貌，即使这不是最容易的对话。" },
  "about.value3.title":    { en: "Honest",           zh: "诚实" },
  "about.value3.desc":     { en: "Good quality work should not be a luxury only big companies can afford. SMEs deserve vendors who are honest about pricing and accountable for results.", zh: "高质量的工作不应该是只有大公司才能负担的奢侈品。中小企业值得拥有对定价诚实、对结果负责的供应商。" },

  "about.company": { en: "VELO WORKING (PTE. LTD.)", zh: "VELO WORKING (PTE. LTD.)" },
  "about.uen":     { en: "UEN: 202609930G",           zh: "UEN: 202609930G" },

  // ─── Contact ──────────────────────────────────────────────────
  "contact.label":   { en: "Get In Touch",     zh: "联系我们" },
  "contact.heading": { en: "Let's Fix Your\nFactory Floor.", zh: "让我们一起修复\n您的工厂车间。" },
  "contact.sub": {
    en: "Whether your ERP sits unused, you're still on Excel, or you need control panels built — every great project starts with a conversation.",
    zh: "无论您的ERP闲置未用、您仍在用Excel、还是需要组装控制面板 — 每个好项目都始于一次对话。",
  },
  "contact.address": {
    en: "540 Sims Ave, Sims Avenue Centre #03-05 Singapore 387603",
    zh: "540 Sims Ave, Sims Avenue Centre #03-05 新加坡 387603",
  },
  "contact.phone":    { en: "(65) 98943004",          zh: "(65) 98943004" },
  "contact.email":    { en: "sales@veloworking.com",  zh: "sales@veloworking.com" },
  "contact.whatsapp": { en: "Chat on WhatsApp",       zh: "WhatsApp 聊天" },
  "contact.form.title":    { en: "Book a Free ERP Audit",    zh: "预约免费ERP诊断" },
  "contact.form.name":     { en: "Name",                     zh: "姓名" },
  "contact.form.company":  { en: "Company Name",             zh: "公司名称" },
  "contact.form.industry": { en: "Industry",                 zh: "行业" },
  "contact.form.headcount": { en: "Company Headcount",       zh: "公司人数" },
  "contact.form.situation": { en: "Your Situation",           zh: "您的情况" },
  "contact.form.situation.graveyard":  { en: "Paid for ERP but nobody uses it",  zh: "买了ERP但没人用" },
  "contact.form.situation.excel":      { en: "Still on Excel / WhatsApp / paper", zh: "还在用Excel/WhatsApp/纸质" },
  "contact.form.situation.growing":    { en: "Growing fast, systems breaking",    zh: "增长快，系统崩溃" },
  "contact.form.situation.lockedin":   { en: "Overpaying, feel trapped by vendor", zh: "付太多钱，被供应商困住" },
  "contact.form.situation.ai":        { en: "Want AI-readiness, no data yet",    zh: "想为AI做准备但没数据" },
  "contact.form.situation.fab":       { en: "Need fabrication / assembly",        zh: "需要制造/装配服务" },
  "contact.form.situation.other":     { en: "Other",                              zh: "其他" },
  "contact.form.message":  { en: "Tell us what's broken",    zh: "告诉我们哪里出了问题" },
  "contact.form.submit":   { en: "Send Inquiry",             zh: "发送咨询" },
  "contact.form.success":  { en: "Thank you! We'll be in touch within 24 hours.", zh: "谢谢！我们会在24小时内联系您。" },

  // ─── Footer ───────────────────────────────────────────────────
  "footer.rights": { en: "All rights reserved.", zh: "版权所有。" },
  "footer.tagline": { en: "Built for the ones still standing.", zh: "为仍在坚持的人而建。" },
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");
  const toggleLang = () => setLang((prev) => (prev === "en" ? "zh" : "en"));
  const t = (key: string): string => translations[key]?.[lang] ?? key;

  return (
    <LanguageContext.Provider value={{ lang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}
