# The Futur Design System Analysis

## Overall Vibe
- Clean, editorial, bold typography-driven design
- Light/off-white background (#F5F5F0 warm gray)
- Dark text (near-black) for maximum contrast
- Minimal use of color — accent colors used sparingly (electric blue/indigo for CTAs, red for sale badges)
- Very generous whitespace — sections breathe
- No gradients, no shadows on cards (very flat)

## Typography
- MASSIVE display headings — likely a heavy-weight serif or sans-serif (appears to be a custom bold sans)
- Very large hero text that fills most of the viewport
- Section labels use UPPERCASE SPACED TRACKING with a horizontal rule after (e.g. "FEATURED COURSES ————")
- Body text is clean sans-serif, generous line-height
- Author names in UPPERCASE MONOSPACE/SMALL CAPS with letter-spacing
- Prices in large, clean type

## Color Palette
- Background: warm off-white/light gray (#F5F5F0 or similar)
- Text: near-black (#1A1A1A)
- CTA buttons: electric blue/indigo (#3300FF or similar vivid blue)
- Sale badges: red
- Cards: white with very subtle border or shadow
- Testimonials section: dark/black background with white text

## Layout
- Full-width sections with generous padding (120px+ vertical)
- Hero: massive text left-aligned, fills viewport, minimal imagery
- Featured section: label + line pattern at top left
- Cards: 3-column grid, clean white cards with image on top, text below
- Testimonials: dark background, large quote text, author info below
- Mission section: centered large text, very editorial feel
- Footer: multi-column links, clean and minimal

## Buttons
- Filled buttons: vivid blue/indigo background, white text, UPPERCASE tracking
- Outlined buttons: border with transparent bg
- No border-radius (or very slight)
- Wide padding, clean

## Section Transitions
- Alternating light/dark sections for rhythm
- No dividers or decorative elements — just background color shifts
- Generous vertical spacing between sections

## Key Patterns to Replicate for Velo Working
1. Massive bold hero text (tagline fills viewport)
2. Warm off-white background as default
3. Dark sections for contrast (testimonials/about)
4. Section labels: UPPERCASE + horizontal line
5. Electric blue/indigo as primary CTA color
6. Clean card layouts with white backgrounds
7. Very generous whitespace throughout
8. Editorial typography hierarchy
9. Minimal decoration — let content speak
