# Engineering Page Test Notes

## Issue: Text nearly invisible on hero section
- The Engineering hero uses bg-[#F5F5F0] (light bg) but the heading text color is text-[#1A1A1A]
- In the screenshot, the text appears extremely faint — almost invisible
- This is likely a framer-motion animation issue — the initial opacity:0 animate to opacity:1 is being captured mid-animation
- The section label and heading ARE there (confirmed by markdown extraction) but the animation hasn't completed when screenshot was taken
- The image (metal fabrication) is NOT visible in the hero — it should be on the right side

## Root Cause: The framer-motion `initial` + `animate` should work immediately on mount
- The text IS animating but the screenshot captures it mid-animation
- The real issue is the image is missing from the hero — it's below the fold

## Fix: The hero section layout needs the image to be visible in the initial viewport
