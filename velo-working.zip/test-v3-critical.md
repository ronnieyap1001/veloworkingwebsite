# Critical Issue - Home Page

The Home page has a massive blank area below the hero section. The IT Solutions summary, Engineering summary, CTA banner, and footer are all invisible.

The markdown extraction shows all the content IS in the DOM (IT & DIGITAL SOLUTIONS, ENGINEERING & FABRICATION, etc.), but the visual rendering shows only the hero and then blank space.

This is caused by the framer-motion whileInView animations — the sections start at opacity:0 and y:24, but the viewport intersection observer isn't triggering because the browser screenshot tool can't scroll to trigger them.

The real issue: The page has 1978px below viewport but End key only scrolled to 241px. The sections below the hero are rendering but invisible due to animations not being triggered.

Fix: Change whileInView to use a much more aggressive viewport trigger, or use CSS animations instead of framer-motion for the below-fold sections.
