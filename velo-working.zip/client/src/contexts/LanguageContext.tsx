import { createContext, useContext, useState, type ReactNode } from "react";

type Lang = "en" | "zh";

interface LanguageContextType {
  lang: Lang;
  toggleLang: () => void;
  t: (key: string) => string;
}

const translations: Record<string, Record<Lang, string>> = {
  // ─── Navigation ───────────────────────────────────────────────
  "nav.home":        { en: "Home",                     zh: "首页" },
  "nav.it":          { en: "Business Process Software", zh: "业务流程软件" },
  "nav.engineering": { en: "Fabrication & Assembly",    zh: "制造与装配" },
  "nav.about":       { en: "About",                    zh: "关于" },
  "nav.contact":     { en: "Contact",                  zh: "联系" },

  // ─── Hero ─────────────────────────────────────────────────────
  "hero.tagline": {
    en: "We Build\nConnections.",
    zh: "我们构建\n连接。",
  },
  "hero.sub": {
    en: "From software systems to steel structures — we connect the processes, machines, and infrastructure that power modern manufacturing.",
    zh: "从软件系统到钢结构 — 我们连接驱动现代制造业的流程、机器和基础设施。",
  },
  "hero.whatsapp": { en: "WhatsApp Us",  zh: "WhatsApp 联系" },
  "hero.quote":    { en: "Get a Quote",  zh: "获取报价" },

  // ─── Home — Business Process Software summary ────────────────
  "home.it.label":   { en: "Business Process Software", zh: "业务流程软件" },
  "home.it.heading": { en: "Connect Your\nOperations.", zh: "连接您的\n运营体系。" },
  "home.it.desc": {
    en: "Your departments should not operate in silos. Our ERP and MES solutions create a single connected thread from procurement to production to delivery — giving you real-time visibility and control across your entire operation.",
    zh: "您的各部门不应各自为政。我们的ERP和MES解决方案从采购到生产到交付建立一条连贯的数据链路 — 让您对整个运营拥有实时可见性和掌控力。",
  },
  "home.it.cta": { en: "Explore Business Process Software", zh: "了解业务流程软件" },

  // ─── Home — Fabrication & Assembly summary ───────────────────
  "home.eng.label":   { en: "Fabrication & Assembly", zh: "制造与装配" },
  "home.eng.heading": { en: "Connect Hardware\nto Systems.",  zh: "连接硬件\n与系统。" },
  "home.eng.desc": {
    en: "Every cable we route, every panel we build, every pipe we install creates a physical connection that keeps your facility running. We bridge the gap between equipment and the control systems that manage them.",
    zh: "我们铺设的每一根电缆、组装的每一个面板、安装的每一段管道，都在创建让您设施持续运转的物理连接。我们弥合设备与管控系统之间的鸿沟。",
  },
  "home.eng.cta": { en: "Explore Fabrication & Assembly", zh: "了解制造与装配服务" },

  // ─── Home — Case Studies ──────────────────────────────────────
  "cases.label":   { en: "Case Studies",                    zh: "案例研究" },
  "cases.heading": { en: "Connections That Delivered.",       zh: "创造价值的连接。" },
  "cases.sub": {
    en: "Real projects where the right connections transformed operations.",
    zh: "通过正确的连接改变运营的真实项目。",
  },
  "cases.tag.erp":  { en: "ERP",  zh: "ERP" },
  "cases.tag.mes":  { en: "MES",  zh: "MES" },
  "cases.tag.fab":  { en: "Fabrication", zh: "制造" },

  "cases.c1.industry": { en: "Precision Machining",  zh: "精密加工" },
  "cases.c1.title": {
    en: "Connected 5 departments into a single ERP — order processing time dropped 60%",
    zh: "将5个部门连接至统一ERP — 订单处理时间缩短60%",
  },
  "cases.c1.challenge": {
    en: "A 45-person precision machining shop ran procurement, production, inventory, invoicing, and sales on three disconnected spreadsheets. Data never matched. Lead times were unpredictable. Management had no single source of truth.",
    zh: "一家45人的精密加工车间在三张互不关联的电子表格上运行采购、生产、库存、开票和销售。数据永远对不上。交货期无法预测。管理层没有统一的数据源。",
  },
  "cases.c1.outcome": {
    en: "We deployed a fully configured Odoo ERP in 8 weeks, connecting procurement, production scheduling, inventory, finance, and CRM into one system. Order processing dropped from 4 hours to 90 minutes. Inventory discrepancies were eliminated. Management gained live dashboards across every function.",
    zh: "我们在8周内部署了全面配置的Odoo ERP，将采购、生产排程、库存、财务和CRM连接至一个系统。订单处理从4小时降至90分钟。库存差异彻底消除。管理层获得了覆盖所有职能的实时仪表盘。",
  },
  "cases.c1.stat1.num":   { en: "60%",   zh: "60%" },
  "cases.c1.stat1.label": { en: "Faster order processing", zh: "订单处理提速" },
  "cases.c1.stat2.num":   { en: "8 wks", zh: "8周" },
  "cases.c1.stat2.label": { en: "Full deployment",         zh: "完整部署" },

  "cases.c2.industry": { en: "Sheet Metal Fabrication", zh: "钣金制造" },
  "cases.c2.title": {
    en: "Connected shop-floor machines to management dashboards — downtime cut 35%",
    zh: "将车间设备连接至管理仪表盘 — 停机时间减少35%",
  },
  "cases.c2.challenge": {
    en: "A sheet metal fabricator had zero real-time visibility into machine utilisation or work order status. Supervisors relied on manual floor walks. Bottlenecks were only discovered after delays had already cascaded through the schedule.",
    zh: "一家钣金制造商对机器利用率和工单状态完全没有实时可见性。主管依赖人工巡检。瓶颈往往在延误已波及整个排程后才被发现。",
  },
  "cases.c2.outcome": {
    en: "We implemented a shop-floor MES that connected every CNC and press brake directly to the existing ERP. Real-time OEE dashboards replaced manual reporting. Supervisors could respond to stoppages within minutes. The connection between machine data and management decisions became instant.",
    zh: "我们部署了车间MES，将每台CNC和折弯机直接连接至现有ERP。实时OEE仪表盘取代了人工报告。主管可在数分钟内响应停机。机器数据与管理决策之间的连接变得即时。",
  },
  "cases.c2.stat1.num":   { en: "35%",   zh: "35%" },
  "cases.c2.stat1.label": { en: "Less production downtime", zh: "生产停机减少" },
  "cases.c2.stat2.num":   { en: "Live",  zh: "实时" },
  "cases.c2.stat2.label": { en: "OEE visibility",           zh: "OEE可见性" },

  "cases.c3.industry": { en: "Process Engineering", zh: "过程工程" },
  "cases.c3.title": {
    en: "Built and connected 12 PLC control panels to a plant-wide SCADA system in 6 weeks",
    zh: "6周内组装12套PLC控制面板并连接至全厂SCADA系统",
  },
  "cases.c3.challenge": {
    en: "A systems integrator needed 12 custom PLC control panels built, wired, tested, and connected to a plant-wide SCADA network for a commissioning deadline. Two previous vendors had failed to deliver on schedule.",
    zh: "一家系统集成商需要在投产截止日期前完成12套定制PLC控制面板的组装、接线、测试，并连接至全厂SCADA网络。此前两家供应商均未能按时交付。",
  },
  "cases.c3.outcome": {
    en: "We completed all 12 panels on schedule with full FAT documentation. Every panel was connected, commissioned, and communicating with the central SCADA system before the deadline. Zero rework required post-installation. The client has since engaged us for ongoing site maintenance and expansion projects.",
    zh: "我们按时完成全部12套面板，附完整FAT文件。每套面板在截止日期前均已连接、调试并与中央SCADA系统通信。安装后无需返工。客户此后持续委托我们进行现场维护和扩建项目。",
  },
  "cases.c3.stat1.num":   { en: "12",     zh: "12" },
  "cases.c3.stat1.label": { en: "Panels connected on time", zh: "按时连接面板" },
  "cases.c3.stat2.num":   { en: "0",      zh: "0" },
  "cases.c3.stat2.label": { en: "Rework incidents",         zh: "返工事故" },

  "cases.disclaimer": {
    en: "Client names withheld for confidentiality. Results are representative of actual project outcomes.",
    zh: "客户名称因保密要求不予披露。成果数据均来自实际项目。",
  },

  // ─── Business Process Software Page ───────────────────────────
  "biz.page.label":   { en: "Business Process Software",   zh: "业务流程软件" },
  "biz.page.heading": { en: "Connect Every Layer\nof Your Business.", zh: "连接您业务的\n每一个层面。" },
  "biz.page.intro": {
    en: "Most operational problems are connection problems. Departments that cannot see each other. Machines that cannot talk to management systems. Data that exists but never reaches the people who need it. We solve this. Our ERP and MES solutions create the digital connections that turn fragmented operations into a single, transparent, controllable system.",
    zh: "大多数运营问题本质上是连接问题。部门之间互不可见。机器无法与管理系统通信。数据存在却永远无法到达需要它的人手中。我们解决这个问题。我们的ERP和MES解决方案创建数字连接，将碎片化的运营转变为一个统一、透明、可控的系统。",
  },

  "biz.stat1.num":   { en: "100%",                  zh: "100%" },
  "biz.stat1.label": { en: "Connected Workflows",       zh: "连通的工作流" },
  "biz.stat2.num":   { en: "Real-time",              zh: "实时" },
  "biz.stat2.label": { en: "Cross-department Visibility", zh: "跨部门可见性" },
  "biz.stat3.num":   { en: "Zero",                   zh: "零" },
  "biz.stat3.label": { en: "Data Silos Remaining",       zh: "残留数据孤岛" },

  "biz.services.label":   { en: "Core Pillars",        zh: "核心支柱" },
  "biz.services.heading": { en: "Two systems. One connected operation.", zh: "两大系统。一个互联的运营体系。" },

  "biz.erp.title": { en: "Flexible ERP Solutions", zh: "灵活的ERP解决方案" },
  "biz.erp.sub":   { en: "Custom · Odoo · Enterprise Integrations", zh: "定制 · Odoo · 企业级集成" },
  "biz.erp.desc": {
    en: "ERP is the central nervous system that connects every function of your business — procurement, inventory, production, finance, sales, and HR — into a single source of truth. When these connections work, decisions are faster, costs are lower, and growth does not create chaos. We configure Odoo, build custom ERP modules, or integrate with your existing enterprise systems. The approach depends entirely on your specific workflows and process requirements. The outcome is always the same: a business where information flows seamlessly from one department to the next.",
    zh: "ERP是连接您企业每一个职能的中枢神经系统 — 采购、库存、生产、财务、销售和人力资源 — 汇聚成单一的真实数据源。当这些连接运作良好时，决策更快，成本更低，增长不会带来混乱。我们配置Odoo、构建定制ERP模块，或与您现有的企业系统集成。方法完全取决于您的具体工作流程和流程需求。结果始终如一：一个信息在各部门之间无缝流动的企业。",
  },

  "biz.mes.title": { en: "MES Integration", zh: "MES制造执行系统集成" },
  "biz.mes.sub":   { en: "Manufacturing Execution System", zh: "制造执行系统" },
  "biz.mes.desc": {
    en: "MES is the bridge that connects your shop floor to your top floor. It captures real-time production data — work order status, machine OEE, quality metrics, operator performance — and feeds it directly into your ERP and management dashboards. The result is a live connection between what management plans and what the factory actually produces. Robotics communicate with software. Machines report their own status. Downtime triggers instant alerts. The gap between planning and reality disappears because the connection between them is always on.",
    zh: "MES是连接您车间与管理层的桥梁。它实时采集生产数据 — 工单状态、设备OEE、质量指标、操作员绩效 — 并直接输入您的ERP和管理仪表盘。结果是管理层计划与工厂实际产出之间建立了实时连接。机器人与软件通信。设备自动报告状态。停机触发即时警报。规划与现实之间的差距消失了，因为它们之间的连接始终在线。",
  },

  // How We Work — Business Process Software
  "biz.how.label":   { en: "How We Work",              zh: "我们的工作方式" },
  "biz.how.heading": { en: "A Proven Path to\nConnected Operations.", zh: "通往互联运营的\n成熟路径。" },

  "biz.step1.title": { en: "Discovery & Business Analysis",       zh: "发现与业务分析" },
  "biz.step1.desc": {
    en: "We map your existing workflows, identify disconnected processes, and understand where information breaks down between departments. No assumptions — we document your actual operations before recommending anything.",
    zh: "我们梳理您现有的工作流程，识别断裂的流程环节，了解信息在部门之间的断点。不做假设 — 在提出任何建议之前，我们先记录您的实际运营。",
  },
  "biz.step2.title": { en: "Solution Configuration & Prototyping", zh: "方案配置与原型验证" },
  "biz.step2.desc": {
    en: "Based on your requirements and process design, we configure the ERP or MES to match your specific operational needs. You see a working prototype of how your departments and systems will be connected before we go into production setup.",
    zh: "根据您的需求和流程设计，我们配置ERP或MES以匹配您的具体运营需求。在进入正式搭建之前，您就能看到各部门和系统将如何被连接的可运行原型。",
  },
  "biz.step3.title": { en: "Setup & Integration",                 zh: "搭建与集成" },
  "biz.step3.desc": {
    en: "We handle data migration, system integration, and configuration with minimal disruption to your operations. Every connection point — between modules, between systems, between your team and the software — is tested and validated.",
    zh: "我们处理数据迁移、系统集成和配置，最大限度减少对您运营的干扰。每一个连接点 — 模块之间、系统之间、您的团队与软件之间 — 都经过测试和验证。",
  },
  "biz.step4.title": { en: "Training, Go-Live & Support",         zh: "培训、上线与持续支持" },
  "biz.step4.desc": {
    en: "We train your team, manage the go-live, and stay on to ensure every connection holds under real operating conditions. Your ROI depends on adoption — and so does our reputation.",
    zh: "我们培训您的团队，管理上线过程，并持续跟进以确保每个连接在实际运营条件下稳定运行。您的投资回报取决于落地效果 — 我们的声誉也是如此。",
  },

  "biz.cta": { en: "Book a Free Discovery Call", zh: "预约免费咨询通话" },

  // ─── Fabrication & Assembly Page ──────────────────────────────
  "eng.page.label":   { en: "Fabrication & Assembly",  zh: "制造与装配" },
  "eng.page.heading": { en: "Connecting Hardware\nto Control.", zh: "连接硬件\n与控制系统。" },
  "eng.page.intro": {
    en: "Every industrial system depends on physical connections — cables that carry signals, panels that house controllers, pipes that link process vessels, assemblies that bring components together into working machines. We build these connections. From raw material to commissioned system, we deliver the physical infrastructure that keeps your facility operating, communicating, and producing.",
    zh: "每一个工业系统都依赖物理连接 — 传输信号的电缆、容纳控制器的面板、连接工艺容器的管道、将零部件组合成运转机器的装配。我们构建这些连接。从原材料到调试完成的系统，我们交付让您的设施持续运营、通信和生产的物理基础设施。",
  },
  "eng.what.label":    { en: "What We Do",                   zh: "我们的服务" },
  "eng.metal.title":   { en: "Full-scale Metal Fabrication",  zh: "全规模金属制造" },
  "eng.metal.desc": {
    en: "Custom metal fabrication including cutting, welding, bending, and finishing for structural and mechanical components. We build the frames, enclosures, brackets, and supports that connect and house your critical equipment — from single prototypes to full production runs.",
    zh: "定制金属制造，包括结构和机械部件的切割、焊接、弯曲和精加工。我们制造连接和容纳您关键设备的框架、外壳、支架和支撑结构 — 从单个原型到批量生产。",
  },
  "eng.box.title":   { en: "Box Build & Control Panel Assembly", zh: "箱体组装与控制面板装配" },
  "eng.box.desc": {
    en: "Complete control panel assembly including PLC, SCADA, and electrical control panels. These are the nerve centres that connect your sensors, actuators, and machines to the software that manages them. We handle component sourcing, wiring, integration, testing, and commissioning — delivering panels that are ready to plug into your control architecture.",
    zh: "完整的控制面板装配，包括PLC、SCADA和电气控制面板。这些是将您的传感器、执行器和机器连接至管理软件的神经中枢。我们负责元件采购、接线、集成、测试和调试 — 交付可直接接入您控制架构的面板。",
  },
  "eng.pcba.title":   { en: "PCBA & Wire Harnessing", zh: "PCBA与线束加工" },
  "eng.pcba.desc": {
    en: "Printed Circuit Board Assembly and custom wire harnessing — the connections that carry power and data between every component in your system. Precision soldering, component placement, and harness fabrication built to your exact specifications. Every wire, every trace, every connector is a link in the chain that keeps your equipment communicating.",
    zh: "印刷电路板组装和定制线束加工 — 在系统中每个组件之间传输电力和数据的连接。精密焊接、元件贴装和线束制造完全按照您的规格定制。每一根线、每一条走线、每一个连接器都是保持设备通信的链条中的一环。",
  },
  "eng.piping.title":   { en: "Piping Fabrication & Installation", zh: "管道制造与安装" },
  "eng.piping.desc": {
    en: "Precision piping systems that connect vessels, drums, tanks, columns, and process equipment into a functioning production line. Stainless steel, carbon steel, and specialty alloy piping — fabricated and installed to specification. Every joint, every weld, every connection is built to handle the pressures and temperatures your process demands.",
    zh: "精密管道系统，将容器、储罐、塔器、塔柱和工艺设备连接成运转的生产线。不锈钢、碳钢和特种合金管道 — 按规格制造和安装。每一个接头、每一道焊缝、每一个连接都经得起您工艺所要求的压力和温度。",
  },
  "eng.site.title":   { en: "Site Labour, Assembly & Testing", zh: "现场劳务、组装与测试" },
  "eng.site.desc": {
    en: "On-site deployment of skilled manpower for industrial projects. We bring components together at your facility — mechanical assembly, electrical connection, system integration, and rigorous commissioning testing. The final step where every individual connection is verified to work as a complete, functioning system.",
    zh: "为工业项目现场部署熟练劳动力。我们在您的设施中将各组件汇集 — 机械组装、电气连接、系统集成和严格的调试测试。这是验证每一个单独连接作为完整运转系统正常工作的最后一步。",
  },

  // How We Work — Fabrication & Assembly
  "eng.how.label":   { en: "Our Process",   zh: "我们的流程" },
  "eng.how.heading": { en: "From Raw Material to\nConnected System.",   zh: "从原材料到\n互联系统。" },
  "eng.step1.title": { en: "Procurement",            zh: "采购" },
  "eng.step1.num":   { en: "01",                     zh: "01" },
  "eng.step1.desc": {
    en: "We source materials, components, and parts from trusted suppliers with verified quality certifications. Our procurement team ensures competitive pricing, material traceability, and on-time delivery for every project.",
    zh: "我们从具有质量认证的可信赖供应商处采购材料、零部件和配件。我们的采购团队确保每个项目的有竞争力的价格、材料可追溯性和准时交付。",
  },
  "eng.step2.title": { en: "Planning",               zh: "规划" },
  "eng.step2.num":   { en: "02",                     zh: "02" },
  "eng.step2.desc": {
    en: "Detailed project planning based on your requirements and specifications. We define scope, timelines, resource allocation, and quality checkpoints — mapping every connection point before any work begins.",
    zh: "根据您的需求和规格进行详细的项目规划。我们确定范围、时间表、资源分配和质量检查点 — 在任何工作开始之前梳理每一个连接点。",
  },
  "eng.step3.title": { en: "Prototyping",            zh: "原型制作" },
  "eng.step3.num":   { en: "03",                     zh: "03" },
  "eng.step3.desc": {
    en: "For complex assemblies, we build prototypes to validate specifications, fit, and functionality before committing to full production. This ensures every connection works correctly at small scale before we scale up.",
    zh: "对于复杂组件，我们在全面生产前制作原型以验证规格、配合和功能。这确保每个连接在小规模下正确运作后再进行量产。",
  },
  "eng.step4.title": { en: "Manufacturing",          zh: "制造" },
  "eng.step4.num":   { en: "04",                     zh: "04" },
  "eng.step4.desc": {
    en: "Our skilled fabricators bring the project to life. Cutting, welding, bending, machining — every process is executed with precision. Every component is built to connect seamlessly with the next.",
    zh: "我们熟练的制造工人将项目变为现实。切割、焊接、弯曲、加工 — 每个工序都经过精密执行。每个组件都为与下一个无缝连接而制造。",
  },
  "eng.step5.title": { en: "Assembly",               zh: "组装" },
  "eng.step5.num":   { en: "05",                     zh: "05" },
  "eng.step5.desc": {
    en: "Components come together. Wiring, mounting, integration — every physical connection is made to specification and double-checked. This is where individual parts become a functioning system.",
    zh: "零部件汇集在一起。接线、安装、集成 — 每个物理连接都按规格完成并经过复核。这是单独零件成为运转系统的环节。",
  },
  "eng.step6.title": { en: "Testing & Quality Control", zh: "测试与质量控制" },
  "eng.step6.num":   { en: "06",                        zh: "06" },
  "eng.step6.desc": {
    en: "Rigorous testing at every stage. Dimensional checks, functional testing, full commissioning — we verify that every connection holds under real operating conditions. Nothing leaves our facility without passing QC.",
    zh: "每个阶段都进行严格测试。尺寸检查、功能测试、全面调试 — 我们验证每个连接在实际运营条件下的可靠性。没有通过质量控制的产品不会离开我们的工厂。",
  },
  "eng.cta": { en: "Start Your Project", zh: "开始您的项目" },

  // ─── About ────────────────────────────────────────────────────
  "about.label":   { en: "About Us",           zh: "关于我们" },
  "about.heading": { en: "Built on Connections.\nDriven by Sincerity.", zh: "以连接为基。\n以诚信为本。" },
  "about.founder": {
    en: "Founded by Ronnie Yap (聪仔), Velo Working was built on a simple belief: the best work happens when people, systems, and infrastructure are properly connected. With deep roots in both engineering and software, we bridge the gap between the physical and digital worlds of manufacturing — creating connections that last.",
    zh: "由 Ronnie Yap（聪仔）创立，Velo Working 建立在一个简单的信念之上：当人员、系统和基础设施被正确连接时，最好的工作就会发生。凭借在工程和软件领域的深厚根基，我们弥合制造业物理世界与数字世界之间的鸿沟 — 创建持久的连接。",
  },
  "about.philosophy": {
    en: "Our core philosophy is simple — sincerity and quality above all else. We treat every project as our own, every client as a long-term partner. No shortcuts, no empty promises. Every connection we build is meant to endure.",
    zh: "我们的核心理念很简单 — 诚意和质量高于一切。我们把每个项目当作自己的项目，把每个客户当作长期合作伙伴。没有捷径，没有空洞的承诺。我们构建的每一个连接都经得起时间考验。",
  },
  "about.company": { en: "VELO WORKING (PTE. LTD.)", zh: "VELO WORKING (PTE. LTD.)" },
  "about.uen":     { en: "UEN: 202609930G",           zh: "UEN: 202609930G" },
  "about.values.label":    { en: "Our Values",  zh: "我们的价值观" },
  "about.value1.title":    { en: "Connection",  zh: "连接" },
  "about.value1.desc":     { en: "We exist to connect — systems to systems, hardware to software, people to solutions. Every project starts with understanding what needs to be linked.", zh: "我们的存在就是为了连接 — 系统与系统、硬件与软件、人与解决方案。每个项目都从理解需要连接什么开始。" },
  "about.value2.title":    { en: "Sincerity",   zh: "诚信" },
  "about.value2.desc":     { en: "Honest communication, transparent pricing, and genuine care for every project. We say what we mean and deliver what we promise.", zh: "诚实沟通、透明定价，真诚对待每一个项目。我们言出必行，承诺必达。" },
  "about.value3.title":    { en: "Quality",     zh: "质量" },
  "about.value3.desc":     { en: "No shortcuts. Every connection we build — digital or physical — meets the highest standards of workmanship and reliability.", zh: "没有捷径。我们构建的每一个连接 — 无论数字还是物理 — 都达到最高的工艺和可靠性标准。" },

  // ─── Contact ──────────────────────────────────────────────────
  "contact.label":   { en: "Get In Touch", zh: "联系我们" },
  "contact.heading": { en: "Let's Build a\nConnection.", zh: "让我们建立\n连接。" },
  "contact.address": {
    en: "540 Sims Ave, Sims Avenue Centre #03-05 Singapore 387603",
    zh: "540 Sims Ave, Sims Avenue Centre #03-05 新加坡 387603",
  },
  "contact.phone":   { en: "(65) 98943004",          zh: "(65) 98943004" },
  "contact.email":   { en: "sales@veloworking.com",  zh: "sales@veloworking.com" },
  "contact.whatsapp": { en: "Chat on WhatsApp", zh: "WhatsApp 聊天" },
  "contact.form.title":    { en: "Request a Quote",         zh: "请求报价" },
  "contact.form.name":     { en: "Name",                    zh: "姓名" },
  "contact.form.company":  { en: "Company Name",            zh: "公司名称" },
  "contact.form.industry": { en: "Industry",                zh: "行业" },
  "contact.form.service":  { en: "Service Required",        zh: "所需服务" },
  "contact.form.service.it":  { en: "Business Process Software (ERP/MES)", zh: "业务流程软件（ERP/MES）" },
  "contact.form.service.eng": { en: "Fabrication & Assembly",              zh: "制造与装配服务" },
  "contact.form.service.both": { en: "Both",                               zh: "两者都需要" },
  "contact.form.budget":   { en: "Estimated Budget",        zh: "预估预算" },
  "contact.form.timeline": { en: "Project Timeline",        zh: "项目时间线" },
  "contact.form.message":  { en: "Additional Details",      zh: "补充说明" },
  "contact.form.submit":   { en: "Send Inquiry",            zh: "发送咨询" },
  "contact.form.success":  { en: "Thank you! We'll be in touch soon.", zh: "谢谢！我们会尽快联系您。" },

  // ─── Footer ───────────────────────────────────────────────────
  "footer.rights": { en: "All rights reserved.", zh: "版权所有。" },
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");
  const toggleLang = () => setLang((prev) => (prev === "en" ? "zh" : "en"));
  const t = (key: string): string => translations[key]?.[lang] ?? key;

  return (
    <LanguageContext.Provider value={{ lang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}

