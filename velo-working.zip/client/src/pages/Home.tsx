import Layout from "@/components/Layout";
import { useLang } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { MessageCircle, FileText, ArrowRight, Monitor, Wrench, Cpu, Cable, Factory, Gauge, Users, Clock, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import Reveal from "@/components/Reveal";

const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%20am%20interested%20in%20your%20solutions...";

const VIDEO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/veloworking_hero_background_193494ff.mp4";

const IMAGES = {
  odoo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/odoo-dashboard_a0c610af.png",
  mes: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/mes-dashboard_67b8707e.png",
  metalFab: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/metal-fabrication-workshop_fe9e7e56.jpg",
  controlPanel: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/control-panel-plc_5c5099c6.webp",
  piping: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/industrial-piping_cfa9e9de.jpg",
  pcba: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/pcba-assembly_25514a10.jpg",
  wireHarness: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/wire-harness-assembly_a353491f.jpg",
  welding: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/welding-sparks_bd5c8bf4.jpeg",
};

export default function Home() {
  const { t, lang } = useLang();

  const stats = [
    { num: "50+", label: lang === "en" ? "Projects Delivered" : "已交付项目" },
    { num: "100%", label: lang === "en" ? "Client Retention" : "客户留存率" },
    { num: "24/7", label: lang === "en" ? "Support Available" : "全天候支持" },
    { num: "2", label: lang === "en" ? "Core Disciplines" : "核心领域" },
  ];

  const industries = lang === "en"
    ? ["Precision Manufacturing", "Sheet Metal & Fabrication", "Process Engineering", "Semiconductor", "Oil & Gas", "Food & Beverage", "Pharmaceutical", "Logistics & Warehousing"]
    : ["精密制造", "钣金与制造", "过程工程", "半导体", "石油与天然气", "食品与饮料", "制药", "物流与仓储"];

  const engServices = [
    { icon: Factory, img: IMAGES.metalFab, title: lang === "en" ? "Metal Fabrication" : "金属制造", desc: lang === "en" ? "Cutting, welding, bending, and finishing for structural and mechanical components." : "结构和机械部件的切割、焊接、弯曲和精加工。" },
    { icon: Cpu, img: IMAGES.controlPanel, title: lang === "en" ? "Control Panel Assembly" : "控制面板装配", desc: lang === "en" ? "PLC, SCADA, and electrical control panels — built, wired, tested, and commissioned." : "PLC、SCADA和电气控制面板 — 组装、接线、测试和调试。" },
    { icon: Cable, img: IMAGES.pcba, title: lang === "en" ? "PCBA & Wire Harnessing" : "PCBA与线束加工", desc: lang === "en" ? "Circuit board assembly and custom cable harnesses connecting every component." : "电路板组装和定制电缆线束，连接每一个组件。" },
    { icon: Gauge, img: IMAGES.piping, title: lang === "en" ? "Piping Systems" : "管道系统", desc: lang === "en" ? "Connecting vessels, drums, tanks, and columns into functioning production lines." : "将容器、储罐、塔器和塔柱连接成运转的生产线。" },
  ];

  return (
    <Layout>
      {/* ─── Video Hero ─── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Video Background */}
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source src={VIDEO_URL} type="video/mp4" />
        </video>
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/65" />

        <div className="container relative z-10 py-24 lg:py-0">
          <div className="max-w-4xl">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-sm tracking-[0.3em] uppercase text-white/60 mb-6"
              style={{ fontFamily: "var(--font-body)" }}
            >
              {lang === "en" ? "Business Process Software · Fabrication & Assembly" : "业务流程软件 · 制造与装配"}
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="text-[clamp(2.8rem,8vw,6rem)] leading-[1.02] tracking-tight text-white whitespace-pre-line"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              {t("hero.tagline")}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-8 text-lg lg:text-xl text-white/70 max-w-2xl leading-relaxed"
              style={{ fontFamily: "var(--font-body)" }}
            >
              {t("hero.sub")}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-brand btn-brand-filled inline-flex items-center gap-2"
              >
                <MessageCircle size={16} />
                {t("hero.whatsapp")}
              </a>
              <Link
                href="/contact"
                className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2"
              >
                <FileText size={16} />
                {t("hero.quote")}
              </Link>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
          <div className="w-[1px] h-12 bg-white/30 animate-pulse" />
        </div>
      </section>

      {/* ─── Stats Bar ─── */}
      <section className="bg-[#1317E4] py-8">
        <div className="container">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            {stats.map((s, i) => (
              <div key={i}>
                <p className="text-3xl lg:text-4xl font-bold text-white" style={{ fontFamily: "var(--font-heading)" }}>{s.num}</p>
                <p className="text-xs tracking-widest uppercase text-white/70 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Business Process Software Summary ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label !text-white">{t("home.it.label")}</p>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mt-8">
            <Reveal>
              <div>
                <h2 className="text-[clamp(2rem,5vw,4rem)] leading-[1.05] text-white whitespace-pre-line" style={{ fontFamily: "var(--font-heading)" }}>
                  {t("home.it.heading")}
                </h2>
                <p className="mt-6 text-lg text-white/50 leading-relaxed max-w-lg">
                  {t("home.it.desc")}
                </p>

                {/* ERP + MES feature blocks */}
                <div className="mt-10 space-y-6">
                  <div className="flex gap-4 items-start">
                    <div className="w-12 h-12 border border-[#1317E4] flex items-center justify-center shrink-0">
                      <Monitor size={22} className="text-[#1317E4]" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-base" style={{ fontFamily: "var(--font-heading)" }}>
                        {lang === "en" ? "Flexible ERP Solutions" : "灵活的ERP解决方案"}
                      </p>
                      <p className="text-white/40 text-sm mt-1 leading-relaxed">
                        {lang === "en"
                          ? "Odoo, custom builds, and enterprise integrations. Connect procurement, inventory, production, finance, and sales into one system."
                          : "Odoo、定制开发和企业级集成。将采购、库存、生产、财务和销售连接至一个系统。"}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start">
                    <div className="w-12 h-12 border border-[#1317E4] flex items-center justify-center shrink-0">
                      <Wrench size={22} className="text-[#1317E4]" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-base" style={{ fontFamily: "var(--font-heading)" }}>
                        {lang === "en" ? "MES Integration" : "MES制造执行系统集成"}
                      </p>
                      <p className="text-white/40 text-sm mt-1 leading-relaxed">
                        {lang === "en"
                          ? "Bridge shop floor to top floor. Real-time OEE, work order tracking, and machine-to-management connectivity."
                          : "连接车间与管理层。实时OEE、工单追踪和设备到管理的连接。"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-10">
                  <Link
                    href="/it-solutions"
                    className="btn-brand btn-brand-filled inline-flex items-center gap-2"
                  >
                    {t("home.it.cta")}
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            </Reveal>

            <Reveal>
              <div className="space-y-4">
                <img
                  src={IMAGES.odoo}
                  alt="Odoo ERP Dashboard"
                  className="w-full h-auto border border-white/10"
                  loading="lazy"
                />
                <img
                  src={IMAGES.mes}
                  alt="MES Manufacturing Dashboard"
                  className="w-full h-auto border border-white/10"
                  loading="lazy"
                />
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ─── Fabrication & Assembly Summary ─── */}
      <section className="bg-[#F8F9FA] py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("home.eng.label")}</p>
            <h2 className="mt-4 text-[clamp(2rem,5vw,4rem)] leading-[1.05] text-[#111111] whitespace-pre-line" style={{ fontFamily: "var(--font-heading)" }}>
              {t("home.eng.heading")}
            </h2>
            <p className="mt-6 text-lg text-[#6B7280] leading-relaxed max-w-2xl">
              {t("home.eng.desc")}
            </p>
          </Reveal>

          {/* Service cards with images */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-14">
            {engServices.map((svc, i) => (
              <Reveal key={i}>
                <div className="group bg-white border border-[#E5E7EB] overflow-hidden hover:border-[#1317E4]/40 transition-colors duration-300">
                  <div className="h-52 overflow-hidden">
                    <img
                      src={svc.img}
                      alt={svc.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <svc.icon size={20} className="text-[#1317E4]" />
                      <h3 className="text-lg font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>{svc.title}</h3>
                    </div>
                    <p className="text-sm text-[#6B7280] leading-relaxed">{svc.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal>
            <div className="mt-10">
              <Link
                href="/engineering"
                className="btn-brand btn-brand-outline inline-flex items-center gap-2"
              >
                {t("home.eng.cta")}
                <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ─── Industries We Serve ─── */}
      <section className="bg-white py-20 lg:py-24 border-t border-[#E5E7EB]">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Industries" : "服务行业"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] leading-tight text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Trusted Across Sectors." : "跨行业的信赖。"}
            </h2>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10">
            {industries.map((ind, i) => (
              <Reveal key={i}>
                <div className="border border-[#E5E7EB] p-5 text-center hover:border-[#1317E4]/40 transition-colors duration-300">
                  <p className="text-sm font-medium text-[#111111]" style={{ fontFamily: "var(--font-body)" }}>{ind}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Why Choose Us ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label !text-white">{lang === "en" ? "Why Velo Working" : "为什么选择 Velo Working"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] leading-tight text-white" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "What Sets Us Apart." : "我们的独特之处。"}
            </h2>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-14">
            {[
              { icon: Users, title: lang === "en" ? "Dual Expertise" : "双重专业", desc: lang === "en" ? "We operate at the intersection of software and hardware. Our team understands both ERP configurations and control panel wiring — giving you a single partner for both digital and physical connections." : "我们在软件和硬件的交汇处运营。我们的团队既懂ERP配置也懂控制面板接线 — 为您提供数字和物理连接的单一合作伙伴。" },
              { icon: Clock, title: lang === "en" ? "On-Time Delivery" : "准时交付", desc: lang === "en" ? "We plan meticulously and execute on schedule. Our track record speaks for itself — every project delivered on time, every commitment honoured." : "我们精心规划并按时执行。我们的记录不言自明 — 每个项目准时交付，每个承诺兑现。" },
              { icon: CheckCircle, title: lang === "en" ? "Long-Term Partnership" : "长期合作", desc: lang === "en" ? "We do not disappear after go-live. Ongoing support, system optimization, and expansion — we stay connected to ensure your investment keeps delivering returns." : "我们不会在上线后消失。持续支持、系统优化和扩展 — 我们保持连接以确保您的投资持续产生回报。" },
            ].map((item, i) => (
              <Reveal key={i}>
                <div className="border border-white/10 p-8 hover:border-[#1317E4]/40 transition-colors duration-300">
                  <item.icon size={28} className="text-[#1317E4] mb-5" />
                  <h3 className="text-lg font-bold text-white mb-3" style={{ fontFamily: "var(--font-heading)" }}>{item.title}</h3>
                  <p className="text-sm text-white/50 leading-relaxed">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Case Studies ─── */}
      <section className="bg-[#F8F9FA] py-24 lg:py-32">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("cases.label")}</p>
            <div className="mt-4 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4 mb-14">
              <h2 className="text-[clamp(2rem,5vw,4rem)] leading-[1.05] text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>
                {t("cases.heading")}
              </h2>
              <p className="text-[#6B7280] text-lg max-w-sm lg:text-right">
                {t("cases.sub")}
              </p>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {[
              { industry: "cases.c1.industry", tag: "cases.tag.erp", title: "cases.c1.title", challenge: "cases.c1.challenge", outcome: "cases.c1.outcome", stat1n: "cases.c1.stat1.num", stat1l: "cases.c1.stat1.label", stat2n: "cases.c1.stat2.num", stat2l: "cases.c1.stat2.label" },
              { industry: "cases.c2.industry", tag: "cases.tag.mes", title: "cases.c2.title", challenge: "cases.c2.challenge", outcome: "cases.c2.outcome", stat1n: "cases.c2.stat1.num", stat1l: "cases.c2.stat1.label", stat2n: "cases.c2.stat2.num", stat2l: "cases.c2.stat2.label" },
              { industry: "cases.c3.industry", tag: "cases.tag.fab", title: "cases.c3.title", challenge: "cases.c3.challenge", outcome: "cases.c3.outcome", stat1n: "cases.c3.stat1.num", stat1l: "cases.c3.stat1.label", stat2n: "cases.c3.stat2.num", stat2l: "cases.c3.stat2.label" },
            ].map((c, i) => (
              <Reveal key={i}>
                <div className="bg-white border border-[#E5E7EB] p-8 flex flex-col hover:border-[#1317E4]/40 transition-colors duration-300 h-full">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-xs tracking-widest text-[#6B7280] uppercase">{t(c.industry)}</span>
                    <span className="text-xs tracking-widest text-[#1317E4] bg-[#1317E4]/10 px-2 py-0.5">{t(c.tag)}</span>
                  </div>
                  <h3 className="text-lg font-bold text-[#111111] leading-snug mb-5" style={{ fontFamily: "var(--font-heading)" }}>
                    {t(c.title)}
                  </h3>
                  <div className="mb-5">
                    <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-2">{lang === "en" ? "Challenge" : "挑战"}</p>
                    <p className="text-sm text-[#6B7280] leading-relaxed">{t(c.challenge)}</p>
                  </div>
                  <div className="mb-6">
                    <p className="text-xs text-[#6B7280] uppercase tracking-widest mb-2">{lang === "en" ? "Outcome" : "成果"}</p>
                    <p className="text-sm text-[#111111]/70 leading-relaxed">{t(c.outcome)}</p>
                  </div>
                  <div className="mt-auto grid grid-cols-2 gap-4 pt-6 border-t border-[#E5E7EB]">
                    <div>
                      <p className="text-2xl font-bold text-[#1317E4]">{t(c.stat1n)}</p>
                      <p className="text-xs text-[#6B7280] mt-1">{t(c.stat1l)}</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-[#1317E4]">{t(c.stat2n)}</p>
                      <p className="text-xs text-[#6B7280] mt-1">{t(c.stat2l)}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <p className="mt-10 text-xs text-[#6B7280]/50 text-center">
            {t("cases.disclaimer")}
          </p>
        </div>
      </section>

      {/* ─── CTA Banner ─── */}
      <section className="bg-[#1317E4] py-20">
        <div className="container text-center">
          <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
            {t("contact.heading").replace("\n", " ")}
          </h2>
          <p className="mt-4 text-white/70 text-lg max-w-lg mx-auto">
            {lang === "en"
              ? "Whether you need ERP, MES, control panels, or piping — every great project starts with a conversation."
              : "无论您需要ERP、MES、控制面板还是管道 — 每个伟大的项目都始于一次对话。"}
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-brand btn-brand-white inline-flex items-center gap-2"
            >
              <MessageCircle size={16} />
              {t("hero.whatsapp")}
            </a>
            <Link
              href="/contact"
              className="btn-brand border border-white text-white hover:bg-white/10 inline-flex items-center gap-2"
            >
              <FileText size={16} />
              {t("hero.quote")}
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
