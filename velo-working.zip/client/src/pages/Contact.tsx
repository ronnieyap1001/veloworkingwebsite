import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { useLang } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { MessageCircle, MapPin, Phone, Mail, Send, Clock, ArrowRight, ChevronDown } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

const WHATSAPP_URL =
  "https://wa.me/6598943004?text=Hi%20Velo%20Working%2C%20I%20am%20interested%20in%20your%20solutions...";

export default function ContactPage() {
  const { t, lang } = useLang();
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    industry: "",
    service: "",
    budget: "",
    timeline: "",
    message: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(
      `New Inquiry from ${formData.name} — ${formData.company}`
    );
    const body = encodeURIComponent(
      `Name: ${formData.name}\nCompany: ${formData.company}\nIndustry: ${formData.industry}\nService: ${formData.service}\nBudget: ${formData.budget}\nTimeline: ${formData.timeline}\n\nMessage:\n${formData.message}`
    );
    window.location.href = `mailto:sales@veloworking.com?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  const faqs = [
    {
      q: lang === "en" ? "What industries do you serve?" : "你们服务哪些行业？",
      a: lang === "en"
        ? "We serve manufacturing SMEs across oil & gas, semiconductor, pharmaceutical, marine & offshore, power & energy, and industrial automation sectors."
        : "我们服务于石油天然气、半导体、制药、海洋离岸、电力能源和工业自动化等领域的制造业中小企业。",
    },
    {
      q: lang === "en" ? "How long does an ERP implementation take?" : "ERP实施需要多长时间？",
      a: lang === "en"
        ? "A typical ERP implementation takes 6-12 weeks depending on the scope and complexity of your operations. We work in phases to minimize disruption to your business."
        : "典型的ERP实施需要6-12周，具体取决于您运营的范围和复杂性。我们分阶段工作，以最大限度减少对您业务的干扰。",
    },
    {
      q: lang === "en" ? "Do you provide on-site support?" : "你们提供现场支持吗？",
      a: lang === "en"
        ? "Yes. Our field teams work on-site for fabrication, assembly, piping installation, and equipment commissioning. For software, we provide both remote and on-site support."
        : "是的。我们的现场团队在现场进行制造、组装、管道安装和设备调试。对于软件，我们提供远程和现场支持。",
    },
    {
      q: lang === "en" ? "Can you handle both software and hardware projects?" : "你们能同时处理软件和硬件项目吗？",
      a: lang === "en"
        ? "Absolutely. That is our core strength. We connect the top floor (ERP, MES) with the shop floor (control panels, piping, fabrication) — delivering integrated solutions that most vendors cannot."
        : "当然可以。这是我们的核心优势。我们将顶层（ERP、MES）与车间（控制面板、管道、制造）连接起来 — 交付大多数供应商无法提供的集成解决方案。",
    },
  ];

  return (
    <Layout>
      {/* ─── Hero ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("contact.label")}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="mt-4 text-[clamp(2.5rem,6vw,5rem)] leading-[1.05] text-white whitespace-pre-line max-w-3xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("contact.heading")}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-lg text-white/50 leading-relaxed max-w-xl"
          >
            {lang === "en"
              ? "Whether you need an ERP system, a control panel, or a complete production line — we are here to help."
              : "无论您需要ERP系统、控制面板还是完整的生产线 — 我们都在这里为您服务。"}
          </motion.p>
        </div>
      </section>

      {/* ─── Quick Contact Strip ─── */}
      <section className="bg-[#1317E4] py-6">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <a href="tel:+6598943004" className="flex items-center justify-center gap-2 text-white hover:text-white/80 transition-colors py-2">
              <Phone size={16} />
              <span className="text-sm font-medium">{t("contact.phone")}</span>
            </a>
            <a href="mailto:sales@veloworking.com" className="flex items-center justify-center gap-2 text-white hover:text-white/80 transition-colors py-2">
              <Mail size={16} />
              <span className="text-sm font-medium">{t("contact.email")}</span>
            </a>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 text-white hover:text-white/80 transition-colors py-2">
              <MessageCircle size={16} />
              <span className="text-sm font-medium">WhatsApp</span>
            </a>
          </div>
        </div>
      </section>

      {/* ─── Contact Info + Form ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 lg:gap-14">
            {/* Left — Contact Info */}
            <div className="lg:col-span-2">
              <Reveal>
                <div className="flex flex-col gap-7">
                  {/* Address */}
                  <div className="flex gap-4">
                    <div className="w-11 h-11 border-2 border-[#E5E7EB] flex items-center justify-center shrink-0">
                      <MapPin size={18} className="text-[#111111]" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#111111] uppercase tracking-wide">
                        {lang === "en" ? "Address" : "地址"}
                      </p>
                      <p className="mt-1 text-sm text-[#6B7280] leading-relaxed">
                        {t("contact.address")}
                      </p>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex gap-4">
                    <div className="w-11 h-11 border-2 border-[#E5E7EB] flex items-center justify-center shrink-0">
                      <Phone size={18} className="text-[#111111]" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#111111] uppercase tracking-wide">
                        {lang === "en" ? "Phone" : "电话"}
                      </p>
                      <a
                        href="tel:+6598943004"
                        className="mt-1 text-sm text-[#6B7280] hover:text-[#1317E4] transition-colors block"
                      >
                        {t("contact.phone")}
                      </a>
                    </div>
                  </div>

                  {/* Email */}
                  <div className="flex gap-4">
                    <div className="w-11 h-11 border-2 border-[#E5E7EB] flex items-center justify-center shrink-0">
                      <Mail size={18} className="text-[#111111]" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#111111] uppercase tracking-wide">
                        {lang === "en" ? "Email" : "电子邮件"}
                      </p>
                      <a
                        href="mailto:sales@veloworking.com"
                        className="mt-1 text-sm text-[#6B7280] hover:text-[#1317E4] transition-colors block"
                      >
                        {t("contact.email")}
                      </a>
                    </div>
                  </div>

                  {/* Operating Hours */}
                  <div className="flex gap-4">
                    <div className="w-11 h-11 border-2 border-[#E5E7EB] flex items-center justify-center shrink-0">
                      <Clock size={18} className="text-[#111111]" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#111111] uppercase tracking-wide">
                        {lang === "en" ? "Operating Hours" : "营业时间"}
                      </p>
                      <p className="mt-1 text-sm text-[#6B7280] leading-relaxed">
                        {lang === "en" ? "Mon – Fri: 9:00 AM – 6:00 PM" : "周一至周五：上午9:00 – 下午6:00"}
                      </p>
                      <p className="text-sm text-[#6B7280] leading-relaxed">
                        {lang === "en" ? "Sat – Sun: By appointment" : "周六至周日：预约制"}
                      </p>
                    </div>
                  </div>

                  {/* WhatsApp */}
                  <a
                    href={WHATSAPP_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-brand btn-brand-filled inline-flex items-center gap-2 w-fit mt-2"
                  >
                    <MessageCircle size={16} />
                    {t("contact.whatsapp")}
                  </a>
                </div>
              </Reveal>
            </div>

            {/* Right — Form */}
            <div className="lg:col-span-3">
              <Reveal delay={0.1}>
                <h2 className="text-2xl font-bold text-[#111111] mb-2" style={{ fontFamily: "var(--font-heading)" }}>
                  {t("contact.form.title")}
                </h2>
                <p className="text-sm text-[#6B7280] mb-6">
                  {lang === "en"
                    ? "Fill in the form below and we will get back to you within 24 hours."
                    : "填写以下表格，我们将在24小时内回复您。"}
                </p>

                {submitted ? (
                  <div className="border-2 border-[#1317E4] p-8 text-center">
                    <p className="text-lg font-bold text-[#1317E4]">{t("contact.form.success")}</p>
                    <p className="mt-2 text-sm text-[#6B7280]">
                      {lang === "en"
                        ? "We will review your inquiry and respond within 24 hours."
                        : "我们将审核您的询问并在24小时内回复。"}
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="form-label">{t("contact.form.name")} *</label>
                        <input
                          type="text"
                          name="name"
                          required
                          value={formData.name}
                          onChange={handleChange}
                          className="form-input"
                        />
                      </div>
                      <div>
                        <label className="form-label">{t("contact.form.company")} *</label>
                        <input
                          type="text"
                          name="company"
                          required
                          value={formData.company}
                          onChange={handleChange}
                          className="form-input"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="form-label">{t("contact.form.industry")} *</label>
                        <input
                          type="text"
                          name="industry"
                          required
                          value={formData.industry}
                          onChange={handleChange}
                          className="form-input"
                        />
                      </div>
                      <div>
                        <label className="form-label">{t("contact.form.service")} *</label>
                        <select
                          name="service"
                          required
                          value={formData.service}
                          onChange={handleChange}
                          className="form-input"
                        >
                          <option value="" disabled>
                            —
                          </option>
                          <option value="IT">{t("contact.form.service.it")}</option>
                          <option value="Engineering">{t("contact.form.service.eng")}</option>
                          <option value="Both">{t("contact.form.service.both")}</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="form-label">{t("contact.form.budget")}</label>
                        <input
                          type="text"
                          name="budget"
                          value={formData.budget}
                          onChange={handleChange}
                          className="form-input"
                        />
                      </div>
                      <div>
                        <label className="form-label">{t("contact.form.timeline")}</label>
                        <input
                          type="text"
                          name="timeline"
                          value={formData.timeline}
                          onChange={handleChange}
                          className="form-input"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="form-label">{t("contact.form.message")}</label>
                      <textarea
                        name="message"
                        rows={4}
                        value={formData.message}
                        onChange={handleChange}
                        className="form-input resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="btn-brand btn-brand-filled inline-flex items-center gap-2 w-fit mt-1"
                    >
                      <Send size={16} />
                      {t("contact.form.submit")}
                    </button>
                  </form>
                )}
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* ─── FAQ Section ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container max-w-3xl">
          <Reveal>
            <p className="section-label">{lang === "en" ? "FAQ" : "常见问题"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Frequently Asked Questions" : "常见问题解答"}
            </h2>
          </Reveal>

          <div className="mt-12 flex flex-col gap-0">
            {faqs.map((faq, i) => (
              <Reveal key={i} delay={i * 0.05}>
                <div className={`border-b border-[#E5E7EB] ${i === 0 ? "border-t" : ""}`}>
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between py-5 text-left"
                  >
                    <span className="text-base font-medium text-[#111111] pr-4">{faq.q}</span>
                    <ChevronDown
                      size={18}
                      className={`text-[#6B7280] shrink-0 transition-transform duration-300 ${
                        openFaq === i ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      openFaq === i ? "max-h-40 pb-5" : "max-h-0"
                    }`}
                  >
                    <p className="text-sm text-[#6B7280] leading-relaxed">{faq.a}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="bg-[#111111] py-16">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Prefer to Talk Directly?" : "更喜欢直接交谈？"}
            </h2>
            <p className="mt-4 text-white/50 text-lg max-w-lg mx-auto">
              {lang === "en"
                ? "Reach us on WhatsApp for a quick response. We typically reply within the hour during business hours."
                : "通过WhatsApp联系我们获取快速回复。在工作时间内，我们通常在一小时内回复。"}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-6">
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-brand btn-brand-filled inline-flex items-center gap-2"
              >
                <MessageCircle size={16} />
                {t("contact.whatsapp")}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
