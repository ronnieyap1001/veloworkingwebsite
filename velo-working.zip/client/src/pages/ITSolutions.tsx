/*
 * DESIGN: Velo Working Brand Guideline — Marina Blue #1317E4
 * Business Process Software page — massively expanded with Odoo modules, MES details
 * Inspired by alitec.sg content depth, with Velo Working "Building Connections" narrative
 */

import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { useLang } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import {
  Database, BarChart3, ArrowRight, Monitor, Wrench, Cloud, Smartphone,
  ShieldCheck, Users, Headphones, Zap, Package, Receipt, ClipboardList,
  Factory, Gauge, Settings, BarChart, Layers, Wifi, Link as LinkIcon
} from "lucide-react";
import { Link } from "wouter";

const IMAGES = {
  odoo: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/odoo-dashboard_a0c610af.png",
  mes: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/mes-dashboard_67b8707e.png",
  odooMrp: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/odoo-mrp-dashboard_9485c01d.webp",
};

export default function ITSolutions() {
  const { t, lang } = useLang();

  const odooModules = [
    { icon: Receipt, name: lang === "en" ? "Accounting & Finance" : "会计与财务", desc: lang === "en" ? "Automated invoicing, bank reconciliation, financial reporting, and multi-currency support." : "自动开票、银行对账、财务报告和多币种支持。" },
    { icon: Package, name: lang === "en" ? "Inventory & Warehouse" : "库存与仓储", desc: lang === "en" ? "Real-time stock tracking, barcode scanning, automated replenishment, and multi-warehouse management." : "实时库存追踪、条码扫描、自动补货和多仓库管理。" },
    { icon: Factory, name: lang === "en" ? "Manufacturing (MRP)" : "制造 (MRP)", desc: lang === "en" ? "Bill of materials, work orders, routing, production planning, and shop floor control." : "物料清单、工单、工艺路线、生产计划和车间管控。" },
    { icon: ClipboardList, name: lang === "en" ? "Sales & CRM" : "销售与CRM", desc: lang === "en" ? "Lead management, quotation pipelines, sales order automation, and customer relationship tracking." : "线索管理、报价流程、销售订单自动化和客户关系追踪。" },
    { icon: Wrench, name: lang === "en" ? "Purchase & Procurement" : "采购管理", desc: lang === "en" ? "Vendor management, purchase orders, approval workflows, and supplier performance tracking." : "供应商管理、采购订单、审批流程和供应商绩效追踪。" },
    { icon: Gauge, name: lang === "en" ? "Quality Control" : "质量控制", desc: lang === "en" ? "Quality checks at every production stage, alerts, corrective actions, and compliance documentation." : "每个生产阶段的质量检查、警报、纠正措施和合规文档。" },
    { icon: Settings, name: lang === "en" ? "Maintenance" : "设备维护", desc: lang === "en" ? "Preventive and corrective maintenance scheduling, equipment tracking, and downtime analysis." : "预防性和纠正性维护计划、设备追踪和停机分析。" },
    { icon: Users, name: lang === "en" ? "HR & Payroll" : "人力资源与薪资", desc: lang === "en" ? "Employee management, attendance, leave tracking, payroll processing, and recruitment." : "员工管理、考勤、请假追踪、薪资处理和招聘。" },
  ];

  const mesFeatures = [
    { icon: BarChart, title: lang === "en" ? "Real-Time OEE Monitoring" : "实时OEE监控", desc: lang === "en" ? "Track Overall Equipment Effectiveness across every machine. Availability, performance, and quality — measured and displayed in real time." : "追踪每台设备的整体设备效率。可用性、性能和质量 — 实时测量和显示。" },
    { icon: Layers, title: lang === "en" ? "Work Order Management" : "工单管理", desc: lang === "en" ? "Digital work orders that flow from ERP to shop floor. Operators see exactly what to produce, in what sequence, with what materials." : "从ERP流向车间的数字化工单。操作员清楚看到生产什么、按什么顺序、用什么材料。" },
    { icon: Wifi, title: lang === "en" ? "IoT & Machine Connectivity" : "IoT与设备连接", desc: lang === "en" ? "Connect PLCs, sensors, and machines directly to your MES. Automatic data capture eliminates manual entry and human error." : "将PLC、传感器和机器直接连接到MES。自动数据采集消除手动输入和人为错误。" },
    { icon: LinkIcon, title: lang === "en" ? "ERP-MES Integration" : "ERP-MES集成", desc: lang === "en" ? "Seamless data flow between your ERP and MES. Production schedules, material consumption, and quality data sync automatically." : "ERP和MES之间的无缝数据流。生产计划、物料消耗和质量数据自动同步。" },
  ];

  const whyChoose = [
    { icon: Cloud, title: lang === "en" ? "Cloud or On-Premise" : "云端或本地部署", desc: lang === "en" ? "Deploy where it makes sense for your business. Cloud for accessibility, on-premise for full control — or hybrid for the best of both." : "在对您业务有意义的地方部署。云端实现可访问性，本地实现完全控制 — 或混合部署兼得两者优势。" },
    { icon: Smartphone, title: lang === "en" ? "Mobile-Ready" : "移动端就绪", desc: lang === "en" ? "Access your ERP and MES from any device. Field technicians, warehouse staff, and managers stay connected from anywhere." : "从任何设备访问您的ERP和MES。现场技术人员、仓库人员和管理人员随时随地保持连接。" },
    { icon: ShieldCheck, title: lang === "en" ? "E-Invoice Ready" : "电子发票就绪", desc: lang === "en" ? "Full compliance with Singapore PEPPOL InvoiceNow and regional e-invoicing standards. Future-proof your billing infrastructure." : "完全符合新加坡PEPPOL InvoiceNow和区域电子发票标准。让您的计费基础设施面向未来。" },
    { icon: Headphones, title: lang === "en" ? "Long-Term Support" : "长期支持", desc: lang === "en" ? "We do not disappear after go-live. Ongoing support, system optimization, user training, and feature expansion — we stay connected." : "我们不会在上线后消失。持续支持、系统优化、用户培训和功能扩展 — 我们保持连接。" },
    { icon: Zap, title: lang === "en" ? "Fast Implementation" : "快速实施", desc: lang === "en" ? "Structured methodology gets you live faster. Core modules can be operational in as little as 4–8 weeks depending on scope." : "结构化方法让您更快上线。核心模块最快4-8周即可投入运营，具体取决于范围。" },
    { icon: LinkIcon, title: lang === "en" ? "System Integration" : "系统集成", desc: lang === "en" ? "Connect your ERP to external systems — procurement portals, government platforms, logistics providers, and custom applications." : "将您的ERP连接至外部系统 — 采购门户、政府平台、物流供应商和定制应用。" },
  ];

  const steps = [
    { num: "01", titleKey: "biz.step1.title", descKey: "biz.step1.desc" },
    { num: "02", titleKey: "biz.step2.title", descKey: "biz.step2.desc" },
    { num: "03", titleKey: "biz.step3.title", descKey: "biz.step3.desc" },
    { num: "04", titleKey: "biz.step4.title", descKey: "biz.step4.desc" },
  ];

  return (
    <Layout>
      {/* ─── Hero Banner ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("biz.page.label")}
          </motion.p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-6">
            <div>
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
                className="text-[clamp(2.5rem,6vw,5rem)] leading-[1.05] text-white whitespace-pre-line"
                style={{ fontFamily: "var(--font-heading)" }}
              >
                {t("biz.page.heading")}
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.15 }}
                className="mt-6 text-lg lg:text-xl text-white/50 leading-relaxed max-w-xl"
              >
                {t("biz.page.intro")}
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
                className="mt-8"
              >
                <Link
                  href="/contact"
                  className="btn-brand btn-brand-filled inline-flex items-center gap-2"
                >
                  {lang === "en" ? "Schedule a Consultation" : "预约咨询"}
                  <ArrowRight size={16} />
                </Link>
              </motion.div>
            </div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block"
            >
              <img
                src={IMAGES.odoo}
                alt="Odoo ERP Dashboard"
                className="w-full h-auto border border-white/10"
                loading="lazy"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ─── Value Proposition Strip ─── */}
      <section className="bg-[#1317E4] py-10">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            {[
              { stat: t("biz.stat1.num"), label: t("biz.stat1.label") },
              { stat: t("biz.stat2.num"), label: t("biz.stat2.label") },
              { stat: t("biz.stat3.num"), label: t("biz.stat3.label") },
            ].map((item) => (
              <div key={item.stat} className="py-4">
                <p className="text-4xl lg:text-5xl font-bold text-white leading-none" style={{ fontFamily: "var(--font-heading)" }}>{item.stat}</p>
                <p className="mt-2 text-xs tracking-[0.05em] uppercase text-white/60">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── ERP Section ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "ERP Solutions" : "ERP解决方案"}</p>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <div>
                <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
                  {t("biz.erp.title")}
                </h2>
                <p className="mt-2 text-xs tracking-[0.05em] uppercase text-[#1317E4] font-medium">{t("biz.erp.sub")}</p>
                <p className="mt-5 text-base lg:text-lg text-[#6B7280] leading-relaxed">
                  {t("biz.erp.desc")}
                </p>
                <p className="mt-4 text-base text-[#6B7280] leading-relaxed">
                  {lang === "en"
                    ? "As an Odoo implementation partner, we configure and deploy the modules your business actually needs — no bloated packages, no unnecessary complexity. Custom builds and enterprise integrations are also available for businesses that have outgrown off-the-shelf solutions."
                    : "作为Odoo实施合作伙伴，我们配置和部署您业务实际需要的模块 — 没有臃肿的套餐，没有不必要的复杂性。对于已超越现成解决方案的企业，我们也提供定制开发和企业级集成。"}
                </p>
              </div>
              <div>
                <img
                  src={IMAGES.odooMrp}
                  alt="Odoo MRP Manufacturing Dashboard"
                  className="w-full h-auto border border-[#E5E7EB]"
                  loading="lazy"
                />
              </div>
            </div>
          </Reveal>

          {/* Odoo Module Grid */}
          <div className="mt-16">
            <Reveal>
              <h3 className="text-xl font-bold text-[#111111] mb-8" style={{ fontFamily: "var(--font-heading)" }}>
                {lang === "en" ? "Modules We Implement" : "我们实施的模块"}
              </h3>
            </Reveal>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0">
              {odooModules.map((mod, i) => (
                <Reveal key={i} delay={i * 0.05}>
                  <div className={`p-6 border border-[#E5E7EB] hover:border-[#1317E4]/40 transition-colors duration-300 ${i < 4 ? "lg:border-b-0" : ""}`}>
                    <mod.icon size={24} className="text-[#1317E4] mb-4" />
                    <h4 className="text-sm font-bold text-[#111111] mb-2" style={{ fontFamily: "var(--font-heading)" }}>{mod.name}</h4>
                    <p className="text-xs text-[#6B7280] leading-relaxed">{mod.desc}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ─── MES Section ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "MES Integration" : "MES集成"}</p>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <div>
                <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
                  {t("biz.mes.title")}
                </h2>
                <p className="mt-2 text-xs tracking-[0.05em] uppercase text-[#1317E4] font-medium">{t("biz.mes.sub")}</p>
                <p className="mt-5 text-base lg:text-lg text-[#6B7280] leading-relaxed">
                  {t("biz.mes.desc")}
                </p>
                <p className="mt-4 text-base text-[#6B7280] leading-relaxed">
                  {lang === "en"
                    ? "Your MES bridges the gap between management decisions and shop-floor execution. We integrate MES with your existing ERP, PLCs, and IoT sensors to create a unified data pipeline — from machine signals to management dashboards."
                    : "您的MES弥合了管理决策和车间执行之间的差距。我们将MES与您现有的ERP、PLC和IoT传感器集成，创建统一的数据管道 — 从机器信号到管理仪表板。"}
                </p>
              </div>
              <div>
                <img
                  src={IMAGES.mes}
                  alt="MES Manufacturing Dashboard"
                  className="w-full h-auto border border-[#E5E7EB]"
                  loading="lazy"
                />
              </div>
            </div>
          </Reveal>

          {/* MES Feature Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-16">
            {mesFeatures.map((feat, i) => (
              <Reveal key={i} delay={i * 0.05}>
                <div className="bg-white border border-[#E5E7EB] p-8 hover:border-[#1317E4]/40 transition-colors duration-300">
                  <div className="flex items-center gap-3 mb-4">
                    <feat.icon size={22} className="text-[#1317E4]" />
                    <h4 className="text-base font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>{feat.title}</h4>
                  </div>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{feat.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Why Choose Us ─── */}
      <section className="bg-white py-20 lg:py-28 border-t border-[#E5E7EB]">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Why Velo Working" : "为什么选择 Velo Working"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight max-w-2xl" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "More Than Software Vendors.\nYour Strategic Partner." : "不仅是软件供应商。\n您的战略合作伙伴。"}
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-14">
            {whyChoose.map((item, i) => (
              <Reveal key={i} delay={i * 0.05}>
                <div className="border border-[#E5E7EB] p-8 hover:border-[#1317E4]/40 transition-colors duration-300">
                  <item.icon size={28} className="text-[#1317E4] mb-5" />
                  <h3 className="text-base font-bold text-[#111111] mb-3" style={{ fontFamily: "var(--font-heading)" }}>{item.title}</h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── How We Work ─── */}
      <section className="bg-[#111111] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label !text-white">{t("biz.how.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("biz.how.heading")}
            </h2>
          </Reveal>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0">
            {steps.map((step, i) => (
              <Reveal key={step.num} delay={i * 0.1}>
                <div
                  className={`relative py-10 px-8 ${
                    i < steps.length - 1
                      ? "border-b md:border-b-0 md:border-r border-white/10"
                      : ""
                  }`}
                >
                  <span className="block text-7xl font-bold text-white/20 leading-none mb-6 select-none" style={{ fontFamily: "var(--font-heading)" }}>
                    {step.num}
                  </span>
                  <div className="w-8 h-[3px] bg-[#1317E4] mb-5" />
                  <h3 className="text-lg font-bold text-white leading-snug" style={{ fontFamily: "var(--font-heading)" }}>
                    {t(step.titleKey)}
                  </h3>
                  <p className="mt-3 text-sm text-white/50 leading-relaxed">
                    {t(step.descKey)}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="bg-[#1317E4] py-16">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("biz.cta")}
            </h2>
            <p className="mt-4 text-white/70 text-lg max-w-lg mx-auto">
              {lang === "en"
                ? "From ERP configuration to MES integration — let us connect your business processes."
                : "从ERP配置到MES集成 — 让我们连接您的业务流程。"}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-6">
              <Link
                href="/contact"
                className="btn-brand btn-brand-white inline-flex items-center gap-2"
              >
                {t("hero.quote")}
                <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
