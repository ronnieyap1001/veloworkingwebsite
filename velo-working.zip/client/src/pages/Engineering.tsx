/*
 * DESIGN: Velo Working Brand Guideline — Marina Blue #1317E4
 * Fabrication & Assembly page — massively expanded with product images
 * Inspired by actenn.com content depth, with Velo Working "Building Connections" narrative
 */

import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { useLang } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import {
  Hammer, Cpu, CircuitBoard, PipetteIcon, HardHat, ArrowRight,
  ShieldCheck, Zap, Award, Cog, Factory, Gauge, CheckCircle
} from "lucide-react";
import { Link } from "wouter";

const IMAGES = {
  metalFab: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/metal-fabrication-workshop_fe9e7e56.jpg",
  controlPanel: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/control-panel-plc_5c5099c6.webp",
  pcba: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/pcba-assembly_25514a10.jpg",
  piping: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/piping-fabrication_f5844d8a.jpg",
  wireHarness: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/wire-harness-assembly_a353491f.jpg",
  welding: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/welding-sparks_bd5c8bf4.jpeg",
  boxBuild: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/box-build-assembly_5af60e19.jpg",
  plcWiring: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/plc-panel-wiring_d9be2e4f.jpg",
  industrialPiping: "https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/industrial-piping_cfa9e9de.jpg",
};

export default function EngineeringPage() {
  const { t, lang } = useLang();

  const services = [
    {
      icon: Hammer,
      titleKey: "eng.metal.title",
      descKey: "eng.metal.desc",
      image: IMAGES.metalFab,
      details: lang === "en"
        ? "From structural steel to precision sheet metal — cutting, bending, welding, and finishing. We handle carbon steel, stainless steel, and aluminum across thicknesses from 0.5mm to 50mm. Every joint, every weld, every surface is inspected to meet your specifications."
        : "从结构钢到精密钣金 — 切割、折弯、焊接和表面处理。我们处理碳钢、不锈钢和铝材，厚度从0.5mm到50mm。每个接头、每条焊缝、每个表面都经过检验以满足您的规格要求。",
    },
    {
      icon: Cpu,
      titleKey: "eng.box.title",
      descKey: "eng.box.desc",
      image: IMAGES.controlPanel,
      details: lang === "en"
        ? "Complete box build solutions — from enclosure fabrication to PLC programming, SCADA integration, and electrical wiring. We build control panels that connect your hardware to your control systems, enabling automated operation and remote monitoring."
        : "完整的箱体组装解决方案 — 从机柜制造到PLC编程、SCADA集成和电气布线。我们构建控制面板，将您的硬件连接到控制系统，实现自动化操作和远程监控。",
    },
    {
      icon: CircuitBoard,
      titleKey: "eng.pcba.title",
      descKey: "eng.pcba.desc",
      image: IMAGES.pcba,
      details: lang === "en"
        ? "Printed circuit board assembly and wire harnessing — connecting electronic components into functional systems. SMT and through-hole assembly, cable harness fabrication, and functional testing to ensure every connection is reliable."
        : "印刷电路板组装和线束制造 — 将电子元件连接成功能系统。SMT和通孔组装、线缆束制造和功能测试，确保每个连接都可靠。",
    },
    {
      icon: PipetteIcon,
      titleKey: "eng.piping.title",
      descKey: "eng.piping.desc",
      image: IMAGES.piping,
      details: lang === "en"
        ? "Piping fabrication and installation connecting vessels, drums, tanks, columns, and process equipment. Carbon steel, stainless steel, and specialty alloys — prefabricated in our workshop or installed on-site to your P&ID specifications."
        : "管道制造和安装，连接容器、罐体、储罐、塔器和工艺设备。碳钢、不锈钢和特种合金 — 在我们的车间预制或按您的P&ID规格在现场安装。",
    },
    {
      icon: HardHat,
      titleKey: "eng.site.title",
      descKey: "eng.site.desc",
      image: IMAGES.welding,
      details: lang === "en"
        ? "On-site labour, mechanical assembly, equipment installation, and rigorous testing. Our field teams work alongside your operations — connecting new equipment to existing infrastructure with minimal disruption to production."
        : "现场劳务、机械组装、设备安装和严格测试。我们的现场团队与您的运营团队并肩工作 — 将新设备连接到现有基础设施，最大限度减少对生产的干扰。",
    },
  ];

  const steps = [
    { num: "01", titleKey: "eng.step1.title", descKey: "eng.step1.desc" },
    { num: "02", titleKey: "eng.step2.title", descKey: "eng.step2.desc" },
    { num: "03", titleKey: "eng.step3.title", descKey: "eng.step3.desc" },
    { num: "04", titleKey: "eng.step4.title", descKey: "eng.step4.desc" },
    { num: "05", titleKey: "eng.step5.title", descKey: "eng.step5.desc" },
    { num: "06", titleKey: "eng.step6.title", descKey: "eng.step6.desc" },
  ];

  const industries = [
    { icon: Factory, name: lang === "en" ? "Oil & Gas" : "石油与天然气" },
    { icon: Cog, name: lang === "en" ? "Semiconductor" : "半导体" },
    { icon: Zap, name: lang === "en" ? "Power & Energy" : "电力与能源" },
    { icon: Gauge, name: lang === "en" ? "Pharmaceutical" : "制药" },
    { icon: Award, name: lang === "en" ? "Marine & Offshore" : "海洋与离岸" },
    { icon: ShieldCheck, name: lang === "en" ? "Industrial Automation" : "工业自动化" },
  ];

  const qualityPoints = [
    lang === "en" ? "Certified welding procedures (WPS/PQR)" : "认证焊接程序 (WPS/PQR)",
    lang === "en" ? "Dimensional inspection and documentation" : "尺寸检验和文件记录",
    lang === "en" ? "Hydrostatic and pneumatic pressure testing" : "液压和气压测试",
    lang === "en" ? "Electrical continuity and insulation testing" : "电气连续性和绝缘测试",
    lang === "en" ? "Full traceability from material to finished product" : "从材料到成品的全程可追溯性",
    lang === "en" ? "Non-destructive testing (NDT) available" : "可提供无损检测 (NDT)",
  ];

  return (
    <Layout>
      {/* ─── Hero Banner ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("eng.page.label")}
          </motion.p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-6">
            <div>
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
                className="text-[clamp(2.5rem,6vw,5rem)] leading-[1.05] text-white whitespace-pre-line"
                style={{ fontFamily: "var(--font-heading)" }}
              >
                {t("eng.page.heading")}
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.15 }}
                className="mt-6 text-lg lg:text-xl text-white/50 leading-relaxed max-w-xl"
              >
                {t("eng.page.intro")}
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
                className="mt-8 flex flex-wrap gap-4"
              >
                <Link
                  href="/contact"
                  className="btn-brand btn-brand-filled inline-flex items-center gap-2"
                >
                  {lang === "en" ? "Request a Quote" : "获取报价"}
                  <ArrowRight size={16} />
                </Link>
              </motion.div>
            </div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block"
            >
              <img
                src={IMAGES.boxBuild}
                alt="Box Build Assembly"
                className="w-full h-[400px] object-cover border border-white/10"
                loading="lazy"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ─── Stats Strip ─── */}
      <section className="bg-[#1317E4] py-10">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { stat: "500+", label: lang === "en" ? "Projects Delivered" : "已交付项目" },
              { stat: "15+", label: lang === "en" ? "Years Experience" : "年经验" },
              { stat: "6", label: lang === "en" ? "Core Capabilities" : "核心能力" },
              { stat: "100%", label: lang === "en" ? "Testing & QC" : "测试与质控" },
            ].map((item) => (
              <div key={item.label} className="py-4">
                <p className="text-3xl lg:text-4xl font-bold text-white leading-none" style={{ fontFamily: "var(--font-heading)" }}>{item.stat}</p>
                <p className="mt-2 text-xs tracking-[0.05em] uppercase text-white/60">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── What We Do — Expanded Service Cards with Images ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("eng.what.label")}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight max-w-3xl" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en"
                ? "Every Connection Engineered to Last"
                : "每一个连接都经过精心工程设计"}
            </h2>
          </Reveal>

          <div className="mt-16 flex flex-col gap-0">
            {services.map((svc, i) => (
              <Reveal key={svc.titleKey} delay={i * 0.05}>
                <div className={`grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center py-12 ${
                  i < services.length - 1 ? "border-b border-[#E5E7EB]" : ""
                }`}>
                  {/* Alternate image side */}
                  <div className={`${i % 2 === 1 ? "lg:order-2" : ""}`}>
                    <img
                      src={svc.image}
                      alt={t(svc.titleKey)}
                      className="w-full h-[300px] lg:h-[350px] object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className={`${i % 2 === 1 ? "lg:order-1" : ""}`}>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 border-2 border-[#1317E4] flex items-center justify-center shrink-0">
                        <svc.icon size={22} className="text-[#1317E4]" />
                      </div>
                      <h3 className="text-xl lg:text-2xl font-bold text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
                        {t(svc.titleKey)}
                      </h3>
                    </div>
                    <p className="text-base text-[#6B7280] leading-relaxed mb-4">
                      {t(svc.descKey)}
                    </p>
                    <p className="text-sm text-[#6B7280] leading-relaxed">
                      {svc.details}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Product Gallery ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Our Work" : "我们的作品"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Built to Connect. Built to Perform." : "为连接而造。为性能而造。"}
            </h2>
          </Reveal>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-12">
            {[
              { src: IMAGES.plcWiring, label: lang === "en" ? "PLC Panel Wiring" : "PLC面板接线" },
              { src: IMAGES.wireHarness, label: lang === "en" ? "Wire Harness Assembly" : "线束组装" },
              { src: IMAGES.industrialPiping, label: lang === "en" ? "Industrial Piping" : "工业管道" },
              { src: IMAGES.welding, label: lang === "en" ? "Precision Welding" : "精密焊接" },
              { src: IMAGES.controlPanel, label: lang === "en" ? "Control Panel" : "控制面板" },
              { src: IMAGES.pcba, label: lang === "en" ? "PCBA Assembly" : "PCBA组装" },
              { src: IMAGES.metalFab, label: lang === "en" ? "Metal Fabrication" : "金属制造" },
              { src: IMAGES.piping, label: lang === "en" ? "Piping Fabrication" : "管道制造" },
            ].map((img, i) => (
              <Reveal key={i} delay={i * 0.03}>
                <div className="relative group overflow-hidden">
                  <img
                    src={img.src}
                    alt={img.label}
                    className="w-full h-[180px] lg:h-[220px] object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                    <p className="text-white text-sm font-medium">{img.label}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Industries We Serve ─── */}
      <section className="bg-white py-20 lg:py-28 border-t border-[#E5E7EB]">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Industries" : "服务行业"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight max-w-2xl" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Connecting Across Industries" : "跨行业连接"}
            </h2>
          </Reveal>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-12">
            {industries.map((ind, i) => (
              <Reveal key={i} delay={i * 0.05}>
                <div className="border border-[#E5E7EB] p-6 text-center hover:border-[#1317E4]/40 transition-colors duration-300">
                  <ind.icon size={28} className="text-[#1317E4] mx-auto mb-3" />
                  <p className="text-sm font-medium text-[#111111]">{ind.name}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Quality Commitment ─── */}
      <section className="bg-[#111111] py-20 lg:py-28">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <Reveal>
                <p className="section-label !text-white">{lang === "en" ? "Quality Assurance" : "质量保证"}</p>
                <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
                  {lang === "en" ? "Every Connection Tested.\nEvery Product Verified." : "每个连接都经过测试。\n每个产品都经过验证。"}
                </h2>
                <p className="mt-6 text-base text-white/50 leading-relaxed">
                  {lang === "en"
                    ? "Quality is not a department — it is embedded in every step of our process. From incoming material inspection to final functional testing, we maintain rigorous standards that our clients depend on."
                    : "质量不是一个部门 — 它嵌入我们流程的每一步。从来料检验到最终功能测试，我们保持客户所依赖的严格标准。"}
                </p>
              </Reveal>
            </div>
            <div>
              <Reveal delay={0.1}>
                <div className="space-y-4">
                  {qualityPoints.map((point, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle size={18} className="text-[#1317E4] mt-0.5 shrink-0" />
                      <p className="text-sm text-white/70 leading-relaxed">{point}</p>
                    </div>
                  ))}
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* ─── How We Work (6 steps) ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{t("eng.how.label")}</p>
            <h2 className="mt-4 text-[clamp(2rem,5vw,3.5rem)] leading-[1.05] text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>
              {t("eng.how.heading")}
            </h2>
          </Reveal>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {steps.map((step, i) => (
              <Reveal key={step.num} delay={i * 0.08}>
                <div className="relative">
                  <span className="text-6xl lg:text-7xl font-bold text-[#1317E4]/10 leading-none block" style={{ fontFamily: "var(--font-heading)" }}>
                    {step.num}
                  </span>
                  <div className="mt-1">
                    <div className="w-10 h-[3px] bg-[#1317E4] mb-3" />
                    <h3 className="text-lg font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>{t(step.titleKey)}</h3>
                    <p className="mt-2 text-sm text-[#6B7280] leading-relaxed">
                      {t(step.descKey)}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="bg-[#1317E4] py-16">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {t("eng.cta")}
            </h2>
            <p className="mt-4 text-white/70 text-lg max-w-lg mx-auto">
              {lang === "en"
                ? "From metal fabrication to control panel assembly — let us build the connections your project needs."
                : "从金属制造到控制面板组装 — 让我们为您的项目构建所需的连接。"}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-6">
              <Link
                href="/contact"
                className="btn-brand btn-brand-white inline-flex items-center gap-2"
              >
                {t("hero.quote")}
                <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
