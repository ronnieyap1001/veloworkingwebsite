import Layout from "@/components/Layout";
import Reveal from "@/components/Reveal";
import { useLang } from "@/contexts/LanguageContext";
import { motion } from "framer-motion";
import { Heart, Shield, Users, ArrowRight, Target, Handshake, Lightbulb } from "lucide-react";
import { Link } from "wouter";

const values = [
  { icon: Heart, titleKey: "about.value1.title", descKey: "about.value1.desc" },
  { icon: Shield, titleKey: "about.value2.title", descKey: "about.value2.desc" },
  { icon: Users, titleKey: "about.value3.title", descKey: "about.value3.desc" },
];

export default function AboutPage() {
  const { t, lang } = useLang();

  const milestones = [
    {
      year: "2026",
      title: lang === "en" ? "Founded in Singapore" : "在新加坡成立",
      desc: lang === "en"
        ? "Velo Working PTE. LTD. established with a clear mission: build connections that make manufacturing businesses run better."
        : "Velo Working PTE. LTD. 成立，使命明确：构建让制造企业运营更好的连接。",
    },
    {
      year: "2026",
      title: lang === "en" ? "First ERP Implementation" : "首个ERP实施项目",
      desc: lang === "en"
        ? "Delivered our first Odoo ERP implementation for a precision machining company, connecting their sales, inventory, and production in one system."
        : "为一家精密加工公司交付了首个Odoo ERP实施项目，将其销售、库存和生产连接在一个系统中。",
    },
    {
      year: "2026",
      title: lang === "en" ? "Engineering Division Launch" : "工程部门启动",
      desc: lang === "en"
        ? "Expanded into fabrication and assembly services — connecting hardware to control systems, vessels to piping, and machines to networks."
        : "扩展至制造和组装服务 — 将硬件连接到控制系统，容器连接到管道，机器连接到网络。",
    },
  ];

  const differentiators = [
    {
      icon: Target,
      title: lang === "en" ? "Manufacturing-First Mindset" : "制造业优先思维",
      desc: lang === "en"
        ? "We are not generalist IT consultants. Every solution we build is designed for the realities of manufacturing — shop floors, production schedules, material flows, and quality requirements."
        : "我们不是通用IT顾问。我们构建的每个解决方案都是为制造业的现实设计的 — 车间、生产计划、物料流和质量要求。",
    },
    {
      icon: Handshake,
      title: lang === "en" ? "Both Sides of the Equation" : "等式的两面",
      desc: lang === "en"
        ? "We understand both software and hardware. ERP and MES on the top floor, fabrication and assembly on the shop floor. This dual expertise means we see the full picture — and build connections others miss."
        : "我们理解软件和硬件。顶层的ERP和MES，车间的制造和组装。这种双重专业知识意味着我们看到全貌 — 并构建他人忽略的连接。",
    },
    {
      icon: Lightbulb,
      title: lang === "en" ? "Practical Over Theoretical" : "实践胜于理论",
      desc: lang === "en"
        ? "We do not sell visions. We deliver working systems. Every recommendation is grounded in what actually works on the factory floor, not what looks good in a presentation."
        : "我们不卖愿景。我们交付可运行的系统。每个建议都基于工厂车间实际有效的方案，而不是在演示文稿中看起来好的东西。",
    },
  ];

  return (
    <Layout>
      {/* ─── Hero ─── */}
      <section className="bg-[#111111] py-24 lg:py-32">
        <div className="container">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="section-label !text-white"
          >
            {t("about.label")}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }}
            className="mt-4 text-[clamp(2.5rem,6vw,5rem)] leading-[1.05] text-white whitespace-pre-line max-w-3xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            {t("about.heading")}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mt-6 text-lg lg:text-xl text-white/50 leading-relaxed max-w-2xl"
          >
            {lang === "en"
              ? "We are a Singapore-based company that builds connections — between software and hardware, between management and shop floor, between your business processes and the systems that run them."
              : "我们是一家总部位于新加坡的公司，专注于构建连接 — 软件与硬件之间、管理层与车间之间、您的业务流程与运行它们的系统之间。"}
          </motion.p>
        </div>
      </section>

      {/* ─── Mission Statement ─── */}
      <section className="bg-[#1317E4] py-14">
        <div className="container text-center">
          <p className="text-2xl lg:text-3xl text-white font-bold leading-snug max-w-3xl mx-auto" style={{ fontFamily: "var(--font-heading)" }}>
            {lang === "en"
              ? '"Built on Sincerity, Delivered with Quality."'
              : '"诚心诚意，精益求精。"'}
          </p>
          <p className="mt-4 text-white/60 text-sm tracking-widest uppercase">
            {lang === "en" ? "Our founding principle" : "我们的创始原则"}
          </p>
        </div>
      </section>

      {/* ─── Founder Story ─── */}
      <section className="bg-white py-20 lg:py-28">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
            <div>
              <Reveal>
                <p className="section-label">{lang === "en" ? "Our Story" : "我们的故事"}</p>
                <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
                  {lang === "en" ? "Founded by an Engineer.\nDriven by Connection." : "由工程师创立。\n以连接为驱动。"}
                </h2>
              </Reveal>
              <Reveal delay={0.1}>
                <p className="mt-6 text-base lg:text-lg text-[#6B7280] leading-relaxed">
                  {t("about.founder")}
                </p>
              </Reveal>
              <Reveal delay={0.15}>
                <p className="mt-4 text-base lg:text-lg text-[#6B7280] leading-relaxed">
                  {t("about.philosophy")}
                </p>
              </Reveal>
              <Reveal delay={0.2}>
                <p className="mt-4 text-base text-[#6B7280] leading-relaxed">
                  {lang === "en"
                    ? "Today, Velo Working serves manufacturing SMEs across Singapore and the region — delivering ERP systems, MES integrations, control panels, piping, and fabrication work. Every project starts with the same question: what connections does this business need to run better?"
                    : "如今，Velo Working 服务于新加坡及区域内的制造业中小企业 — 交付ERP系统、MES集成、控制面板、管道和制造工作。每个项目都从同一个问题开始：这个企业需要什么连接才能运营得更好？"}
                </p>
              </Reveal>

              <Reveal delay={0.25}>
                <div className="mt-8 border-t border-[#E5E7EB] pt-6">
                  <p className="text-sm tracking-[0.05em] uppercase text-[#9CA3AF]">
                    {t("about.company")}
                  </p>
                  <p className="mt-1 text-sm tracking-[0.05em] uppercase text-[#9CA3AF]">
                    {t("about.uen")}
                  </p>
                </div>
              </Reveal>
            </div>

            <Reveal delay={0.15}>
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/hero-people-QFoexycwyCB2AhTzxG7h3D.webp"
                alt="Velo Working team at work"
                className="w-full h-auto object-cover"
                loading="lazy"
              />
              <div className="mt-3 w-24 h-[3px] bg-[#1317E4]" />
            </Reveal>
          </div>
        </div>
      </section>

      {/* ─── What Makes Us Different ─── */}
      <section className="bg-[#F8F9FA] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Why Us" : "为什么选择我们"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight max-w-2xl" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "What Makes Velo Working Different" : "Velo Working 的不同之处"}
            </h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            {differentiators.map((item, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className="bg-white border border-[#E5E7EB] p-8 h-full hover:border-[#1317E4]/40 transition-colors duration-300">
                  <item.icon size={28} className="text-[#1317E4] mb-5" />
                  <h3 className="text-base font-bold text-[#111111] mb-3" style={{ fontFamily: "var(--font-heading)" }}>{item.title}</h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Company Timeline ─── */}
      <section className="bg-white py-20 lg:py-28 border-t border-[#E5E7EB]">
        <div className="container">
          <Reveal>
            <p className="section-label">{lang === "en" ? "Our Journey" : "我们的历程"}</p>
            <h2 className="mt-4 text-[clamp(1.8rem,4vw,3rem)] text-[#111111] leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Building Connections Since Day One" : "从第一天起就在构建连接"}
            </h2>
          </Reveal>

          <div className="mt-12 flex flex-col gap-0">
            {milestones.map((ms, i) => (
              <Reveal key={i} delay={i * 0.1}>
                <div className={`grid grid-cols-1 lg:grid-cols-12 gap-6 py-8 ${
                  i < milestones.length - 1 ? "border-b border-[#E5E7EB]" : ""
                }`}>
                  <div className="lg:col-span-2">
                    <span className="text-3xl font-bold text-[#1317E4]" style={{ fontFamily: "var(--font-heading)" }}>{ms.year}</span>
                  </div>
                  <div className="lg:col-span-10">
                    <h3 className="text-lg font-bold text-[#111111]" style={{ fontFamily: "var(--font-heading)" }}>{ms.title}</h3>
                    <p className="mt-2 text-sm text-[#6B7280] leading-relaxed">{ms.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Values ─── */}
      <section className="bg-[#111111] py-20 lg:py-28">
        <div className="container">
          <Reveal>
            <p className="section-label !text-white">{t("about.values.label")}</p>
          </Reveal>

          <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
            {values.map((val, i) => (
              <Reveal key={val.titleKey} delay={i * 0.1}>
                <div className="border border-white/10 p-7 lg:p-9 hover:border-[#1317E4]/40 transition-colors duration-300">
                  <div className="w-12 h-12 border-2 border-[#1317E4] flex items-center justify-center mb-5">
                    <val.icon size={22} className="text-[#1317E4]" />
                  </div>
                  <h3 className="text-xl font-bold text-white" style={{ fontFamily: "var(--font-heading)" }}>{t(val.titleKey)}</h3>
                  <p className="mt-3 text-sm text-white/50 leading-relaxed">{t(val.descKey)}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="bg-[#1317E4] py-16">
        <div className="container text-center">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,4vw,3rem)] text-white leading-tight" style={{ fontFamily: "var(--font-heading)" }}>
              {lang === "en" ? "Let's Build Something Together" : "让我们一起构建"}
            </h2>
            <p className="mt-4 text-white/70 text-lg max-w-lg mx-auto">
              {lang === "en"
                ? "Whether you need an ERP system, a control panel, or a complete production line — we are here to connect the pieces."
                : "无论您需要ERP系统、控制面板还是完整的生产线 — 我们都在这里为您连接各个环节。"}
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-6">
              <Link
                href="/contact"
                className="btn-brand btn-brand-white inline-flex items-center gap-2"
              >
                {t("hero.quote")}
                <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </Layout>
  );
}
