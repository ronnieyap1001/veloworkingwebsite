/*
 * DESIGN: Velo Working Brand Guideline — Marina Blue, Libre Baskerville + DM Sans
 * Multi-page nav with wouter links
 */

import { useLang } from "@/contexts/LanguageContext";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";

const navItems = [
  { key: "nav.home", href: "/" },
  { key: "nav.it", href: "/it-solutions" },
  { key: "nav.engineering", href: "/engineering" },
  { key: "nav.about", href: "/about" },
  { key: "nav.contact", href: "/contact" },
];

export default function Navbar() {
  const { lang, toggleLang, t } = useLang();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/98 backdrop-blur-md border-b border-[#E5E7EB]"
          : "bg-white border-b border-transparent"
      }`}
    >
      <div className="container flex items-center justify-between h-16 lg:h-20">
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-3 hover:opacity-70 transition-opacity"
        >
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/velo-logo-dark_615c188b.png"
            alt="Velo Working logo"
            className="w-8 h-8 object-contain"
          />
          <span
            className="text-base lg:text-lg font-bold tracking-tight text-[#111111]"
            style={{ fontFamily: "var(--font-body)" }}
          >
            VELO WORKING
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-7">
          {navItems.map((item) => (
            <Link
              key={item.key}
              href={item.href}
              className={`text-[0.8125rem] tracking-[0.04em] uppercase transition-colors ${
                location === item.href
                  ? "text-[#1317E4] font-medium"
                  : "text-[#6B7280] hover:text-[#111111]"
              }`}
              style={{ fontFamily: "var(--font-body)" }}
            >
              {t(item.key)}
            </Link>
          ))}
          <button
            onClick={toggleLang}
            className="text-[0.8125rem] tracking-[0.04em] uppercase border border-[#111111] px-4 py-1.5 text-[#111111] hover:bg-[#111111] hover:text-white transition-all"
            style={{ fontFamily: "var(--font-body)" }}
          >
            {lang === "en" ? "中文" : "EN"}
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden p-2 text-[#111111]"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-white border-t border-[#E5E7EB]">
          <div className="container py-6 flex flex-col gap-4">
            {navItems.map((item) => (
              <Link
                key={item.key}
                href={item.href}
                className={`text-sm tracking-[0.04em] uppercase transition-colors text-left py-2 ${
                  location === item.href
                    ? "text-[#1317E4] font-medium"
                    : "text-[#6B7280] hover:text-[#111111]"
                }`}
                style={{ fontFamily: "var(--font-body)" }}
              >
                {t(item.key)}
              </Link>
            ))}
            <button
              onClick={() => {
                toggleLang();
                setMobileOpen(false);
              }}
              className="text-sm tracking-[0.04em] uppercase border border-[#111111] px-4 py-2 text-[#111111] hover:bg-[#111111] hover:text-white transition-all w-fit"
              style={{ fontFamily: "var(--font-body)" }}
            >
              {lang === "en" ? "中文" : "EN"}
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
