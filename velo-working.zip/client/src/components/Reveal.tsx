import { useEffect, useRef, useState, type ReactNode } from "react";

/**
 * Reveal component - reveals content with a subtle fade-up animation
 * when it enters the viewport. Content is visible by default (no flash of invisible content).
 * Animation is progressive enhancement only.
 */
export default function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [hasAnimated, setHasAnimated] = useState(false);
  const [shouldAnimate, setShouldAnimate] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    // Check if element is already in viewport on mount
    const rect = el.getBoundingClientRect();
    const inViewport = rect.top < window.innerHeight && rect.bottom > 0;

    if (inViewport) {
      // Already in viewport - animate immediately
      setShouldAnimate(true);
      requestAnimationFrame(() => setHasAnimated(true));
      return;
    }

    // Not in viewport - set up observer
    setShouldAnimate(true);
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHasAnimated(true);
          obs.disconnect();
        }
      },
      { threshold: 0.01, rootMargin: "50px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // If JS hasn't loaded or observer hasn't set up, content is fully visible (no FOIC)
  const style: React.CSSProperties = shouldAnimate
    ? {
        opacity: hasAnimated ? 1 : 0,
        transform: hasAnimated ? "translateY(0)" : "translateY(16px)",
        transition: `opacity 0.5s ease ${delay}s, transform 0.5s ease ${delay}s`,
      }
    : {};

  return (
    <div ref={ref} className={className} style={style}>
      {children}
    </div>
  );
}
