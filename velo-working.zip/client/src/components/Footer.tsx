import { useLang } from "@/contexts/LanguageContext";
import { Link } from "wouter";

export default function Footer() {
  const { t } = useLang();
  const year = new Date().getFullYear();

  return (
    <footer className="bg-[#111111] py-12 border-t border-white/5">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
          {/* Brand */}
          <div>
            <Link
              href="/"
              className="flex items-center gap-3 hover:opacity-70 transition-opacity w-fit"
            >
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/velo-logo-white_67456626.png"
                alt="Velo Working logo"
                className="w-8 h-8 object-contain"
              />
              <span
                className="text-lg font-bold tracking-tight text-white"
                style={{ fontFamily: "var(--font-body)" }}
              >
                VELO WORKING
              </span>
            </Link>
            <p className="mt-3 text-sm text-white/40 leading-relaxed max-w-xs">
              {t("hero.sub").slice(0, 100)}...
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <p
              className="text-xs tracking-[0.05em] uppercase text-white/60 mb-4 font-medium"
              style={{ fontFamily: "var(--font-body)" }}
            >
              {t("nav.home")}
            </p>
            <div className="flex flex-col gap-2">
              {[
                { key: "nav.it", href: "/it-solutions" },
                { key: "nav.engineering", href: "/engineering" },
                { key: "nav.about", href: "/about" },
                { key: "nav.contact", href: "/contact" },
              ].map((item) => (
                <Link
                  key={item.key}
                  href={item.href}
                  className="text-sm text-white/40 hover:text-white/80 transition-colors"
                >
                  {t(item.key)}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <p
              className="text-xs tracking-[0.05em] uppercase text-white/60 mb-4 font-medium"
              style={{ fontFamily: "var(--font-body)" }}
            >
              {t("nav.contact")}
            </p>
            <div className="flex flex-col gap-2 text-sm text-white/40">
              <a href="tel:+6598943004" className="hover:text-white/80 transition-colors">
                (65) 98943004
              </a>
              <a
                href="mailto:sales@veloworking.com"
                className="hover:text-white/80 transition-colors"
              >
                sales@veloworking.com
              </a>
              <p>540 Sims Ave, #03-05<br />Singapore 387603</p>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p
            className="text-xs tracking-[0.05em] uppercase text-white/30"
            style={{ fontFamily: "var(--font-body)" }}
          >
            &copy; {year} Velo Working (Pte. Ltd.) &mdash; {t("footer.rights")}
          </p>
        </div>
      </div>
    </footer>
  );
}
