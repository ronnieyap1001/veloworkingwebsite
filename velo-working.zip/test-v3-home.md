# Home Page Test v3

The hero text "Built on Sincerity, Delivered with Quality." is barely visible - it appears as very faint gray on the off-white background. This is the framer-motion initial opacity:0 animate to opacity:1 being captured mid-animation.

The CTA buttons (WHATSAPP US, GET A QUOTE) are also barely visible at the bottom of the hero.

The dark section below the hero (IT summary) is visible but the text inside it is also faint.

Key issue: The framer-motion animations are making content invisible on initial load because the screenshot captures the page before animations complete.

Fix: Use animate instead of whileInView for above-the-fold hero content so it animates immediately on mount.
