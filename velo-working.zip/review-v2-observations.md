# V2 Design Review Observations

## What's Working
- About section: Dark bg, white text, geometric image on right — looks editorial and clean
- Chinese translations render perfectly with Noto Sans SC
- Nav: Clean sticky bar with VELO WORKING logo, uppercase nav items, language toggle
- Engineering section: Full-width welding image renders beautifully
- Contact section: Clean form with underline inputs, WhatsApp button in green
- Footer: Minimal dark footer with copyright

## Issues Found
1. **Engineering section nav scroll**: When clicking "Engineering" nav, it scrolls past the section heading to the image area. The section heading/cards are above the image but the scroll offset might be off.
2. **Blank space between sections**: There appears to be large blank areas when scrolling — this is caused by framer-motion animations starting at opacity:0 and the viewport not triggering them until scrolled into view. The `margin: "-100px"` viewport setting helps but may not be enough.
3. **Hero section**: The hero text appears correctly on the off-white background. The hero image shows on the right side.

## What Needs Polish
- The Engineering section has too much empty space above the image — the section label and heading should appear before the image
- The scroll navigation could be smoother — consider reducing animation delays
- Mobile hamburger menu needs testing
