# Image URLs for V3 Multi-Page

hero-people: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/hero-people-QFoexycwyCB2AhTzxG7h3D.webp
it-team: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/it-team-SE5v7cy2vekqGakA5oTsPV.webp
metal-fabrication: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/metal-fabrication-JkN64WC3JANBJyR2syrMdJ.webp
control-panel: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/control-panel-dmap8iC6LVp7aHHrGCj8RC.webp
piping-work: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/piping-work-FCBEDQdCbxu7oHjLAxSGiK.webp
