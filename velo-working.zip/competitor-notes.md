# Competitor Research Notes

## Alitec.sg (Odoo Gold Partner)
- **Positioning:** Odoo Gold Partner ERP System for SMEs
- **Key Content Sections:**
  - Odoo Accounting, Inventory, Sales (with grant support up to 50%)
  - E-Invoice support (Singapore PEPPOL InvoiceNow + Malaysia MyInvois)
  - ERP Services: consultancy, implementation, 10-day projects possible
  - Customized Solutions: new business processes, mobile apps, IoT projects
  - Why Choose section: Go Cloud, Direct Involvement, Long Term, Integration, IoT, Mobile
- **Odoo Modules Mentioned:** CRM, Sales, Accounting, Inventory, Delivery, Invoicing
- **Key Differentiators:** 
  - Cloud-based (browser only)
  - On-site training and testing
  - Long-term support after go-live
  - Integration with external systems (procurement portals, custom systems)
  - IoT for shop floor automation
  - Mobile apps for field technicians connected to ERP
- **Grant Support:** Singapore PSG grant up to 50%
- **Pages to check:** Solutions, Services, Odoo details

## Alitec Odoo Module Breakdown (from their Odoo page):
- **Finance:** Accounting, Invoicing, Expenses, Payroll, Documents, Sign
- **Sales:** CRM, Sales, POS, Subscriptions, Rental
- **Websites:** Website Builder, eCommerce, Blog, Live Chat, eLearning
- **Inventory & MRP:** Inventory, Barcode, Manufacturing (MRP), PLM, Purchase, Maintenance, Quality
- **HR:** Employees, Recruitment, Time Off, Appraisals, Fleet
- **Marketing:** Social, Email, SMS, Events, Marketing Automation
- **Services:** Project, Timesheet, Field Service, Helpdesk, Planning
- **Productivity:** Discuss, Approvals, Calendar, VoIP, IoT
- **Key Selling Points:** Innovation (fast evolution), Affordable (transparent pricing), Customisable (Studio), Enterprise Ready, Cloud hosting
- **Pricing comparison:** Odoo vs Microsoft Dynamics, Salesforce, etc.

## Actenn.com (Cable Assembly / Box Build / PCBA)
- **Positioning:** Custom Cable Assembly Solutions, Industrial & Automotive
- **Key Services:**
  - Industrial & Automotive Cables
  - Box Build & Control Panels (PLC, SCADA, Electrical)
  - PCBA (Printed Circuit Board Assembly)
  - Military Defense Cables & Harnesses
  - Defense Optics and Fiber Technology
- **Content Structure:**
  - Stats bar: 30+ Products, 15+ Years, 100+ Team
  - Service cards with images and Read More links
  - Why Choose section: Quality Assurance, Innovation, Reliable Performance
  - Industries We Serve: Automotive, Industrial Automation, Defense, Electronics/IoT, Energy
  - Process: Consultation → Design → Manufacturing → Testing → Delivery
  - Quality commitment: ISO 9001, electrical/environmental/durability testing
  - Sustainability section
- **Key Takeaway:** Heavy use of product images showing actual cables, control panels, PCBAs
- **Images to source:** Control panels, cable assemblies, PCBA boards, piping, metal fabrication

## Content to Adapt for Velo Working:
- Odoo module breakdown (CRM, Sales, Inventory, Accounting, Manufacturing, etc.)
- Cloud vs on-premise options
- Integration capabilities (IoT, external systems)
- Grant support mention (if applicable)
- Why Choose Us section with similar pillars
- E-Invoice readiness
- Mobile app connectivity
