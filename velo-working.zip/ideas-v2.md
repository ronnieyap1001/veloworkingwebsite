# Velo Working Redesign — The Futur-Inspired Direction

## Chosen Design: "Editorial Industrial"

Inspired directly by thefutur.com — bold, typography-driven, editorial layout with generous whitespace and minimal decoration. Adapted for a B2B industrial/engineering context.

### Design Movement
Modern Editorial / Swiss Typography — content-first, type-as-hero, maximum clarity.

### Core Principles
1. Typography IS the design — massive headings, clear hierarchy, no decorative noise
2. Generous whitespace — every section breathes, 120px+ vertical padding
3. Alternating light/dark rhythm — warm off-white and near-black sections
4. Minimal color — one vivid accent (electric indigo) for CTAs, everything else is black/white/gray

### Color Philosophy
- Background: warm off-white `#F5F5F0` (not sterile white)
- Dark sections: near-black `#141414`
- Text: `#1A1A1A` on light, `#F5F5F0` on dark
- Primary accent: electric indigo `#4400FF` (CTAs, links, highlights)
- Secondary accent: warm red `#E63946` (sparingly, for emphasis)
- Muted text: `#6B6B6B`

### Typography System
- Display/Headings: **DM Sans** (bold, 800 weight) — geometric, modern, not Inter
- Body: **DM Sans** (400/500) — clean and readable
- Chinese: **Noto Sans SC** — matches DM Sans proportions
- Monospace labels: **JetBrains Mono** — for section labels and technical details
- Hero heading: 5rem–7rem, tight line-height (1.05), tight tracking
- Section labels: 0.75rem, UPPERCASE, letter-spacing 0.2em, with horizontal line

### Layout Paradigm
- Full-width sections, max-width container for content (1280px)
- Hero: text fills 70% of viewport, minimal imagery
- Sections alternate warm-white / near-black backgrounds
- Service cards: clean white cards on light bg, or dark cards on dark bg
- Asymmetric grids (7/5 or 8/4 splits)

### Signature Elements
1. Section labels: `UPPERCASE LABEL ————` (text + thin horizontal rule)
2. Oversized typography that commands attention
3. Clean card components with hover lift effect

### Interaction Philosophy
- Subtle, purposeful — no flashy animations
- Buttons: filled indigo with white text, slight scale on hover
- Cards: subtle translateY(-4px) on hover
- Smooth scroll with generous easing
- Fade-in-up on scroll for content blocks

### Animation
- Entrance: fade-in + translateY(20px), 0.6s ease-out, staggered
- Hover: scale(1.02) on buttons, translateY(-4px) on cards
- No bouncing, no spinning, no parallax — clean and professional

### Sections (in order)
1. Hero — massive tagline, subtext, two CTAs
2. IT & Software Solutions — services with clean cards
3. Engineering & Site Services — services with cards
4. About Us — founder profile, company philosophy
5. Contact & Lead Capture — form, WhatsApp, contact info
6. Footer — minimal, clean
