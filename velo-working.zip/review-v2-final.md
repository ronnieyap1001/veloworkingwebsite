V2 Design Review - Editorial Industrial Style

Hero: Massive DM Sans typography, off-white bg, smart factory image with indigo accent line. Clean CTA buttons. Looks great.

IT Section: Dark bg (#141414), section label "IT & SOFTWARE SOLUTIONS" with line, massive heading "Non-conventional Digitalization." Two service cards with indigo icon squares (Odoo ERP + MES). Image below heading on left. Layout is clean and editorial.

Need to verify: Engineering section, About section, Contact form, Footer, Language toggle, Mobile responsiveness.

All markdown content extracted correctly - all sections present and properly ordered.
No console errors, no TypeScript errors.
