# Critical Issue - Reveal Component

The Reveal component uses IntersectionObserver which works in real browsers but the screenshot tool
can't trigger the intersection properly. The Engineering section and CTA are invisible.

The IT section IS visible because the user scrolled to it and the observer triggered.
But the Engineering section below it never got triggered.

Solution: Instead of starting at opacity:0, use CSS animation with @keyframes that auto-plays
when the element enters the viewport. Or better: just remove the Reveal animations entirely
for a cleaner, more professional look. The editorial style doesn't need scroll animations.

Actually the simplest fix: Make Reveal start visible (opacity:1) by default and only animate
as enhancement. Use CSS animation-fill-mode approach instead.
