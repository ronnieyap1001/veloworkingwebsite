# Brand Guideline Extraction Notes

## Source: StyleGuideVol.2(InDesign).pdf — "Monterkap Finance" template
Ronnie is using this as a style reference for Velo Working.

## Typography (Pages 28-31)
- **Primary Typeface (Headings):** Cambon — a contemporary flared serif
  - Styles: Regular, Semibold, Semibold Italic, Bold Italic
  - Used for headlines and display text
- **Secondary Typeface (Body):** TT Hoves — modern sans-serif
  - Styles: Regular, Medium
  - Used for paragraphs, text blocks, subheads, marketing materials

### Typography System (Page 31)
- **Headline Level 1:** Size 4.5x, Cambon Semibold, Tracking 0pts, Leading 120%
- **Headline Level 2:** Size 3x, Cambon Semibold, Tracking 0pts, Leading 110%
- **Subhead:** Size 1.5x, TT Hoves Medium, Tracking -20pts, Leading 100%
- **Body:** Size 1x, TT Hoves Regular, Tracking -10pts, Leading 100%
- **Caption:** Size 0.5x, TT Hoves Regular, Tracking -10pts, Leading 100%

## Brand Colors (Pages 37-40)
- **Marina Blue (Primary):** #1317E4 — RGB(19, 23, 228). The official brand color. Modern yet conservative.
- **Light Blue (Complementary):** #8CC5FF — RGB(140, 197, 255)
- **Sea White (Complementary):** #EAF4FF — RGB(234, 244, 255)
- **Darker blues for depth:** #1210B5, #1215D3, #2C5CEE, #3D8DF8
- **Lighter blues for illustrations:** #8ABBFB, #A4CAFC, #BED9FD, #99C4FC, #79BAFC, #569AE0
- **Near-white tints:** #F2F8FF, #FCFDFF, #EAF4FF

### Color Guidelines (Page 40)
- NO light text on light backgrounds
- NO gradients
- NO textures replacing colors
- NO similar colors placed on each other
- Use appropriate color proportions
- Keep the official Marina Blue unchanged

## Layout Style (Pages 6, 32, 42)
- Clean, minimal, generous whitespace
- Section labels in Marina Blue (small text, left-aligned, TT Hoves)
- Large bold serif headings (Cambon Semibold)
- Body text in sans-serif (TT Hoves Regular), justified
- Two-column layouts: left 1/3 for labels/descriptions, right 2/3 for content
- Horizontal rules as section dividers (thin, subtle)
- Website nav: Logo left, links right, clean white bg
- 5px spacing between title and paragraph

## Typography Rules (Pages 33-35)
- DO NOT use Cambon in body text blocks
- DO NOT apply gradient to type
- DO NOT put pictures/patterns in type
- DO NOT stack type
- DO NOT set headlines in ALL CAPS
- DO NOT set headlines all lowercase
- DO NOT apply drop shadows or effects
- DO NOT use color to highlight text in body
- DO NOT substitute with non-approved fonts

## Brand Personality & Tone (Pages 7-10)
- Bold, confident, wise, full of energy
- Smart, confident, direct, formal
- Avoid business jargon
- DO: Be confident and formal, clear and authentic, creative
- DON'T: Brag or act cocky, be casual, write sloppy, be too playful

## Key Design Principles
- Conservative, serious, corporate look
- Serif (Cambon) for authority, sans-serif (TT Hoves) for modernity
- Marina Blue #1317E4 as primary accent, black for text, white for backgrounds
- NO gradients, NO textures, NO drop shadows
- Flat, clean, professional
