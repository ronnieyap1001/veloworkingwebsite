# CDN URLs - V2 (Real Product Images + Video)

## Video
- Hero Video: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/veloworking_hero_background_193494ff.mp4

## Product Images
- Control Panel PLC: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/control-panel-plc_5c5099c6.webp
- Box Build Assembly: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/box-build-assembly_5af60e19.jpg
- Metal Fabrication Workshop: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/metal-fabrication-workshop_fe9e7e56.jpg
- Welding Sparks: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/welding-sparks_bd5c8bf4.jpeg
- Piping Fabrication: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/piping-fabrication_f5844d8a.jpg
- Wire Harness Assembly: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/wire-harness-assembly_a353491f.jpg
- PCBA Assembly: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/pcba-assembly_25514a10.jpg
- Odoo MRP Dashboard: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/odoo-mrp-dashboard_9485c01d.webp
- Odoo Dashboard: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/odoo-dashboard_a0c610af.png
- MES Dashboard: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/mes-dashboard_67b8707e.png
- Industrial Piping: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/industrial-piping_cfa9e9de.jpg
- PLC Panel Wiring: https://d2xsxph8kpxj0f.cloudfront.net/310519663341245422/gZvUETNcduVn7NphDwsd5L/plc-panel-wiring_d9be2e4f.jpg

## Previous Images (still available)
- Hero People: (from previous upload)
- IT Team: (from previous upload)
- Metal Fabrication: (from previous upload)
- Control Panel: (from previous upload)
- Piping Work: (from previous upload)
