# Scroll Test Observations

The screenshot at pixels_above=362 shows the bottom of the hero section with CTA buttons (invisible due to animation opacity:0 state) and below that the VELO WORKING logo + nav items appear again. This is actually the sticky navbar becoming visible as the page scrolls. The navbar is `fixed top-0` so it stays at the top.

The actual issue: the CTA buttons in the hero (WhatsApp Us + Get a Quote) appear as empty dashed boxes because the framer-motion animation hasn't triggered yet in the screenshot. They DO render once the animation completes.

The scroll from clicking SERVICES landed at pixels_above=362, which is still in the hero section. The services section (id="services") starts further down. The scroll-padding-top of 5rem should offset for the fixed nav.

The problem: `scrollIntoView({ behavior: "smooth" })` in the Navbar doesn't respect `scroll-padding-top`. Need to use `window.scrollTo` with manual offset calculation instead.
