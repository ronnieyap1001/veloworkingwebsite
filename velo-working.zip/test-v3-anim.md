# Animation Issue

The hero section uses framer-motion animate (not whileInView) so it should animate on mount.
The screenshot is captured before the 0.8s animation completes, showing the text at very low opacity.
The hero image is also not visible - it's at opacity 0 during the initial animation.

The below-fold sections (IT summary, Engineering summary, CTA) are using the new Reveal component.
The dark section at the bottom of viewport suggests the IT section IS rendering.

Need to wait 2 seconds and check again to see if animations completed.
