# V3 Multi-Page Test Notes

## IT Solutions Page
- Hero section renders correctly with dark bg, heading, and IT team image
- Service cards (01, 02, 03) are in the markdown content but not visible in the screenshot — they're hidden by framer-motion animations
- The page shows a large blank area between the service section and the CTA/footer
- The CTA section (purple bg) appears at the bottom
- The footer nav is duplicated — there's a second nav bar appearing mid-page (this is the sticky nav)
- Issue: framer-motion `whileInView` animations are not triggering because the content starts below the fold

## Fix needed:
1. Change framer-motion animations to use `initial` + `animate` instead of `whileInView` for content that should be visible on page load
2. Or reduce the viewport margin significantly
3. The service cards section has too much whitespace/padding
