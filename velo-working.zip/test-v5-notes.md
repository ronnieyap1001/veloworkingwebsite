# Test V5 — Building Connections Narrative

## Home Page
- Hero text "We Build Connections." is rendering but very faint — framer-motion entrance animation mid-transition (normal for screenshot tool)
- Markdown extraction confirms ALL new copy is correct:
  - Hero: "We Build Connections."
  - Subtext: "From software systems to steel structures — we connect the processes, machines, and infrastructure..."
  - BPS section: "Connect Your Operations."
  - Engineering section: "Connect Hardware to Systems."
  - Case Studies: "Connections That Delivered."
  - CTA: "Let's Build a Connection."
  - ERP card: "Connects All Departments"
  - MES card: "Connects Machines to Management"
- All new narrative copy is rendering correctly
- Nav shows: HOME, BUSINESS PROCESS SOFTWARE, FABRICATION & ASSEMBLY, ABOUT, CONTACT
- CTA buttons: WhatsApp Us, Get a Quote

## Still need to verify:
- IT Solutions page copy
- Engineering page copy
- About page copy
- Contact page copy
- Chinese translations
