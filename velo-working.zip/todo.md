# Narrative Rewrite — "Building Connections"

## Todo
- [ ] Read all current LanguageContext translations
- [ ] Read all page components for hardcoded text
- [ ] Rewrite hero tagline and subtext around "connections"
- [ ] Rewrite Business Process Software page copy — ERP connects processes, MES connects robotics to software
- [ ] Rewrite Fabrication & Assembly page copy — cables/control boxes connect hardware to control, piping connects vessels
- [ ] Rewrite About page — founder story through lens of building connections
- [ ] Rewrite Case Studies — frame outcomes as connection achievements
- [ ] Rewrite Home page summaries for both service pillars
- [ ] Update all Chinese translations to match
- [ ] Check for any hardcoded English text in components (Challenge/Outcome labels, etc.)
- [ ] Test all pages
