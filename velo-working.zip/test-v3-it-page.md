# IT Solutions Page Observations

1. Page navigated to /it-solutions but viewport shows the middle of the page
   - There's a duplicate navbar visible at the bottom of the viewport
   - This is actually the sticky navbar becoming visible as the page scrolled
   - The issue is the page doesn't scroll to top on navigation

2. The hero section text is invisible - framer-motion animation caught mid-transition
   - Same issue as before - the animate prop takes time to complete

3. The markdown extraction shows ALL content is present:
   - Hero with "Non-conventional Digitalization"
   - 3 service cards (Flexible ERP, MES, End-to-End Digital Transformation)
   - CTA section

4. FIX NEEDED: Add scroll-to-top on route change in the Layout or App component
